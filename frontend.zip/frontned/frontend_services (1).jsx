// ============================================================================
// FILE: src/services/api.js - API Service Layer
// ============================================================================
// Handles all HTTP requests to the backend with JWT authentication

import axios from 'axios';
import { useStore } from '../store/useStore';
import toast from 'react-hot-toast';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';
const API_TIMEOUT = process.env.REACT_APP_API_TIMEOUT || 30000;

// Create axios instance
const apiClient = axios.create({
  baseURL: API_URL,
  timeout: API_TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add JWT token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = \`Bearer \${token}\`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('access_token');
      localStorage.removeItem('user');
      window.location.href = '/login';
      toast.error('Session expired. Please login again.');
    } else if (error.response?.status === 403) {
      toast.error('Access denied. Insufficient permissions.');
    } else if (error.response?.data?.detail) {
      toast.error(error.response.data.detail);
    } else if (error.message === 'Network Error') {
      toast.error('Network error. Check your connection.');
    }
    return Promise.reject(error);
  }
);

export default apiClient;

// ============================================================================
// FILE: src/services/endpoints.js - API Endpoints
// ============================================================================

export const endpoints = {
  // Authentication
  auth: {
    register: '/api/auth/register',
    login: '/api/auth/login',
  },
  
  // Patient Vitals
  vitals: {
    update: '/api/vitals/update',
  },
  
  // Beds
  beds: {
    reserve: '/api/beds/reserve',
  },
  
  // Hospitals
  hospitals: {
    search: '/api/hospitals/search',
  },
  
  // Routes
  routes: {
    optimize: '/api/route/optimize',
  },
  
  // Siren
  siren: {
    toggle: '/api/siren/toggle',
  },
  
  // Alerts
  alerts: {
    sms: '/api/alerts/sms',
    insurance: '/api/insurance/alert',
  },
  
  // RAG & LLM
  rag: {
    query: '/api/rag/query',
    generatePathway: '/api/pathways/generate-with-rag',
  },
  
  // Health
  health: '/health',
};

// ============================================================================
// FILE: src/services/auth.js - Authentication Service
// ============================================================================

import apiClient, { endpoints } from './endpoints';

export const authService = {
  // Register new user
  register: async (userData) => {
    const response = await apiClient.post(endpoints.auth.register, userData);
    return response.data;
  },

  // Login user
  login: async (credentials) => {
    const response = await apiClient.post(endpoints.auth.login, credentials);
    if (response.data.access_token) {
      localStorage.setItem('access_token', response.data.access_token);
      localStorage.setItem('token_type', response.data.token_type);
    }
    return response.data;
  },

  // Logout user
  logout: () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
    localStorage.removeItem('token_type');
  },

  // Get current token
  getToken: () => localStorage.getItem('access_token'),

  // Check if user is authenticated
  isAuthenticated: () => !!localStorage.getItem('access_token'),
};

// ============================================================================
// FILE: src/store/useStore.js - Zustand State Management
// ============================================================================

import { create } from 'zustand';

export const useStore = create((set) => ({
  // User state
  user: null,
  isAuthenticated: false,
  userRole: null,

  // UI state
  loading: false,
  error: null,
  successMessage: null,

  // Chat state
  chatMessages: [],
  chatHistory: [],

  // Patient data
  patients: [],
  currentPatient: null,

  // Hospital data
  hospitals: [],
  selectedHospital: null,

  // Ambulance data
  ambulances: [],
  selectedAmbulance: null,

  // Actions
  setUser: (user) => set({ user, isAuthenticated: !!user, userRole: user?.role }),
  logout: () => set({ user: null, isAuthenticated: false, userRole: null }),

  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
  setSuccess: (message) => set({ successMessage: message }),
  clearMessages: () => set({ error: null, successMessage: null }),

  addChatMessage: (message) => set((state) => ({
    chatMessages: [...state.chatMessages, message],
  })),
  clearChatMessages: () => set({ chatMessages: [] }),
  setChatHistory: (history) => set({ chatHistory: history }),

  setPatients: (patients) => set({ patients }),
  setCurrentPatient: (patient) => set({ currentPatient: patient }),

  setHospitals: (hospitals) => set({ hospitals }),
  setSelectedHospital: (hospital) => set({ selectedHospital: hospital }),

  setAmbulances: (ambulances) => set({ ambulances }),
  setSelectedAmbulance: (ambulance) => set({ selectedAmbulance: ambulance }),
}));

// ============================================================================
// FILE: src/App.jsx - Main Application
// ============================================================================

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from './store/useStore';
import { Toaster } from 'react-hot-toast';
import { useEffect } from 'react';

// Pages
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Chat from './pages/Chat';
import Patients from './pages/Patients';
import Hospitals from './pages/Hospitals';
import Ambulances from './pages/Ambulances';
import Settings from './pages/Settings';
import NotFound from './pages/NotFound';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const isAuthenticated = useStore((state) => state.isAuthenticated);
  return isAuthenticated ? children : <Navigate to="/login" replace />;
};

// Role-Based Route Component
const RoleBasedRoute = ({ children, allowedRoles }) => {
  const isAuthenticated = useStore((state) => state.isAuthenticated);
  const userRole = useStore((state) => state.userRole);
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(userRole)) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

export default function App() {
  const isAuthenticated = useStore((state) => state.isAuthenticated);

  useEffect(() => {
    // Check if user is already logged in
    const token = localStorage.getItem('access_token');
    const user = localStorage.getItem('user');
    if (token && user) {
      useStore.setState({ 
        isAuthenticated: true, 
        user: JSON.parse(user) 
      });
    }
  }, []);

  return (
    <Router>
      <Toaster position="top-right" />
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Protected Routes */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/chat"
          element={
            <ProtectedRoute>
              <Chat />
            </ProtectedRoute>
          }
        />
        <Route
          path="/patients"
          element={
            <ProtectedRoute>
              <Patients />
            </ProtectedRoute>
          }
        />
        <Route
          path="/hospitals"
          element={
            <ProtectedRoute>
              <Hospitals />
            </ProtectedRoute>
          }
        />
        <Route
          path="/ambulances"
          element={
            <RoleBasedRoute allowedRoles={['doctor', 'paramedic', 'admin']}>
              <Ambulances />
            </RoleBasedRoute>
          }
        />
        <Route
          path="/settings"
          element={
            <ProtectedRoute>
              <Settings />
            </ProtectedRoute>
          }
        />

        {/* Catch-all */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

// ============================================================================
// Continue with component files in separate files...
// ============================================================================
