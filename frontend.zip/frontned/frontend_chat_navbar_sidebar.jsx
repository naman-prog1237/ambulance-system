// ============================================================================
// FILE: src/pages/Chat.jsx - LLM Chat Interface with Streaming (ChatGPT-style)
// ============================================================================

import { useState, useRef, useEffect } from 'react';
import { useStore } from '../store/useStore';
import Navbar from '../components/Common/Navbar';
import Sidebar from '../components/Common/Sidebar';
import apiClient from '../services/api';
import { endpoints } from '../services/endpoints';
import { Send, MessageCircle, Loader } from 'lucide-react';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

export default function Chat() {
  const chatMessages = useStore((state) => state.chatMessages);
  const addChatMessage = useStore((state) => state.addChatMessage);
  const clearChatMessages = useStore((state) => state.clearChatMessages);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState('');
  const messagesEndRef = useRef(null);

  // Auto-scroll to latest message
  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, streamingMessage]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    addChatMessage(userMessage);
    setInput('');
    setLoading(true);
    setStreamingMessage('');

    try {
      // Send query to RAG endpoint
      const response = await apiClient.post(endpoints.rag.query, {
        query: input,
        top_k: 5,
      });

      // Format RAG results with streaming effect
      const ragResults = response.data.results;
      let formattedResponse = `📚 **Medical Guidelines Retrieved (${ragResults.length} results):**\n\n`;

      // Add sources
      ragResults.forEach((result, index) => {
        formattedResponse += `**${index + 1}. ${result.source}** (Category: ${result.category}, Score: ${(result.relevance_score * 100).toFixed(0)}%)\n`;
        formattedResponse += `${result.document.substring(0, 200)}...\n\n`;
      });

      formattedResponse += `⏱️ Processing time: ${response.data.processing_time_ms.toFixed(0)}ms`;

      // Stream the response character by character
      await streamMessage(formattedResponse);

      const aiMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: formattedResponse,
        timestamp: new Date(),
        sources: ragResults,
      };

      addChatMessage(aiMessage);
      setStreamingMessage('');
    } catch (error) {
      toast.error('Failed to get response. Try again.');
      setStreamingMessage('');
    } finally {
      setLoading(false);
    }
  };

  // Simulate streaming effect
  const streamMessage = (message) => {
    return new Promise((resolve) => {
      let index = 0;
      const interval = setInterval(() => {
        if (index < message.length) {
          setStreamingMessage((prev) => prev + message[index]);
          index++;
        } else {
          clearInterval(interval);
          resolve();
        }
      }, 10); // 10ms per character for smooth typing effect
    });
  };

  const handleNewChat = () => {
    clearChatMessages();
    setStreamingMessage('');
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        <main className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-gray-50 to-white">
            {/* Empty State */}
            {chatMessages.length === 0 && !streamingMessage && (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <MessageCircle size={64} className="text-gray-300 mb-4" />
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Ask Medical Questions</h2>
                <p className="text-gray-600 mb-6 max-w-md">
                  Get instant answers powered by Medical Guidelines + LLM. Perfect for clinical decisions.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <button
                    onClick={() => setInput('What is the treatment for hypertension?')}
                    className="p-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-sm transition"
                  >
                    💊 Hypertension Treatment
                  </button>
                  <button
                    onClick={() => setInput('What is the first aid for cardiac arrest?')}
                    className="p-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-sm transition"
                  >
                    ❤️ Cardiac Arrest
                  </button>
                  <button
                    onClick={() => setInput('What are the symptoms of stroke?')}
                    className="p-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-sm transition"
                  >
                    🧠 Stroke Symptoms
                  </button>
                  <button
                    onClick={() => setInput('What is sepsis protocol?')}
                    className="p-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-sm transition"
                  >
                    🔬 Sepsis Management
                  </button>
                </div>
              </div>
            )}

            {/* Chat Messages */}
            {chatMessages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-md lg:max-w-2xl px-4 py-3 rounded-lg ${
                    message.role === 'user'
                      ? 'bg-blue-600 text-white rounded-br-none'
                      : 'bg-gray-200 text-gray-900 rounded-bl-none'
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                  <p className={`text-xs mt-1 ${
                    message.role === 'user' ? 'text-blue-100' : 'text-gray-500'
                  }`}>
                    {format(message.timestamp, 'HH:mm')}
                  </p>
                </div>
              </div>
            ))}

            {/* Streaming Message */}
            {streamingMessage && (
              <div className="flex justify-start">
                <div className="max-w-md lg:max-w-2xl px-4 py-3 rounded-lg bg-gray-200 text-gray-900 rounded-bl-none">
                  <p className="text-sm whitespace-pre-wrap">{streamingMessage}</p>
                  <div className="inline-block ml-1 h-4 w-0.5 bg-gray-600 animate-pulse"></div>
                </div>
              </div>
            )}

            {/* Loading indicator */}
            {loading && !streamingMessage && (
              <div className="flex justify-center">
                <div className="flex items-center gap-2 text-gray-600">
                  <Loader className="animate-spin" size={20} />
                  <span>Retrieving medical guidelines...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="bg-white border-t border-gray-200 p-4">
            <form onSubmit={handleSendMessage} className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask a medical question... (powered by RAG + LLM)"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={loading}
              />
              <button
                type="submit"
                disabled={loading || !input.trim()}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-6 py-2 rounded-lg transition flex items-center gap-2"
              >
                {loading ? <Loader className="animate-spin" size={18} /> : <Send size={18} />}
                Send
              </button>
              <button
                type="button"
                onClick={handleNewChat}
                className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-lg transition"
              >
                Clear
              </button>
            </form>
            <p className="text-xs text-gray-500 mt-2">
              💡 Tip: Ask specific medical questions for better results
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}

// ============================================================================
// FILE: src/components/Common/Navbar.jsx - Navigation Bar
// ============================================================================

import { useStore } from '../../store/useStore';
import { useNavigate } from 'react-router-dom';
import { LogOut, Settings, Bell } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Navbar() {
  const user = useStore((state) => state.user);
  const logout = useStore((state) => state.logout);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
    logout();
    toast.success('Logged out successfully');
    navigate('/login');
  };

  return (
    <nav className="bg-white border-b border-gray-200 px-6 py-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🏥</span>
          <h1 className="text-xl font-bold text-gray-800">Smart Healthcare</h1>
        </div>

        <div className="flex items-center gap-6">
          {/* Notifications */}
          <button className="relative text-gray-600 hover:text-gray-900">
            <Bell size={20} />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>

          {/* Settings */}
          <button
            onClick={() => navigate('/settings')}
            className="text-gray-600 hover:text-gray-900"
          >
            <Settings size={20} />
          </button>

          {/* User Info */}
          <div className="flex items-center gap-3 pl-6 border-l border-gray-200">
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
              {user?.name?.charAt(0) || 'U'}
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-medium text-gray-900">{user?.name}</p>
              <p className="text-xs text-gray-500">{user?.role}</p>
            </div>
          </div>

          {/* Logout */}
          <button
            onClick={handleLogout}
            className="text-gray-600 hover:text-red-600 transition"
            title="Logout"
          >
            <LogOut size={20} />
          </button>
        </div>
      </div>
    </nav>
  );
}

// ============================================================================
// FILE: src/components/Common/Sidebar.jsx - Navigation Sidebar
// ============================================================================

import { useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import {
  LayoutDashboard,
  MessageCircle,
  Users,
  Hospital,
  Ambulance,
  Settings,
  Menu,
  X,
} from 'lucide-react';

export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(true);
  const location = useLocation();
  const userRole = useStore((state) => state.userRole);

  const menuItems = [
    { name: 'Dashboard', icon: LayoutDashboard, href: '/dashboard' },
    { name: 'Chat (RAG+LLM)', icon: MessageCircle, href: '/chat' },
    { name: 'Patients', icon: Users, href: '/patients' },
    { name: 'Hospitals', icon: Hospital, href: '/hospitals' },
    ...(userRole !== 'patient' ? [{ name: 'Ambulances', icon: Ambulance, href: '/ambulances' }] : []),
    { name: 'Settings', icon: Settings, href: '/settings' },
  ];

  const isActive = (href) => location.pathname === href;

  return (
    <>
      {/* Mobile Toggle */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed top-4 left-4 z-50 p-2 bg-blue-600 text-white rounded-lg"
      >
        {isOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Sidebar */}
      <aside
        className={`${
          isOpen ? 'w-64' : 'w-0'
        } bg-gray-900 text-white transition-all duration-300 flex flex-col overflow-hidden md:w-64`}
      >
        <div className="p-6 border-b border-gray-700">
          <h2 className="text-2xl font-bold">🚑 Ambulance</h2>
          <p className="text-xs text-gray-400 mt-1">Healthcare Management</p>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                to={item.href}
                className={`flex items-center gap-3 px-4 py-2 rounded-lg transition ${
                  isActive(item.href)
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-800'
                }`}
              >
                <Icon size={20} />
                <span className="hidden md:inline">{item.name}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-gray-700 text-xs text-gray-400">
          <p>v1.0.0</p>
          <p>© 2024 Smart Ambulance</p>
        </div>
      </aside>
    </>
  );
}

// ============================================================================
// More components and pages continue...
// ============================================================================
