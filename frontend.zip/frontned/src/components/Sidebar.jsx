import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  HeartPulse, 
  Building2, 
  Bed, 
  MapPin, 
  Siren, 
  AlertTriangle, 
  Shield,
  LogOut 
} from 'lucide-react';

import { useAuth } from '../contexts/AuthContext';

const navItems = [
  { path: '/', name: 'Dashboard', icon: LayoutDashboard, auth: true },
  { path: '/vitals', name: 'Vitals Monitor', icon: HeartPulse, auth: true },
  { path: '/hospitals', name: 'Hospital Search', icon: Building2, auth: true },

  { path: '/beds', name: 'Bed Reservation', icon: Bed, auth: true },
  { path: '/route', name: 'Route Optimizer', icon: MapPin, auth: true },
  { path: '/siren', name: 'Siren Control', icon: Siren, auth: true },
  { path: '/alerts', name: 'Guardian Alerts', icon: AlertTriangle, auth: true },
  { path: '/insurance', name: 'Insurance', icon: Shield, auth: true },
];

export default function Sidebar({ open, onClose }) {
  const { user, logout } = useAuth();
  const location = useLocation();

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div 
          className="fixed inset-0 z-40 bg-black/50 lg:hidden" 
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-64 transform -translate-x-full bg-white/80 backdrop-blur-xl
        shadow-neumorphic border-r border-gray-200 lg:translate-x-0 lg:static lg:inset-0 transition-transform duration-200 ease-in-out
        ${open ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-gray-200">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary-600 to-blue-700 bg-clip-text text-transparent">
              🚑 Smart Ambulance
            </h1>
            {user && (
              <p className="text-sm text-gray-600 mt-1 truncate">{user.role}</p>
            )}
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`
                  flex items-center px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200
                  ${location.pathname === item.path 
                    ? 'neumorphic text-primary-700 shadow-neumorphic-inset bg-gradient-to-r from-primary-50 to-blue-50' 
                    : 'text-gray-700 hover:text-primary-600 hover:bg-gray-50 hover:shadow-neumorphic'
                  }
                `}
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Logout */}
          {user && (
            <div className="p-4 mt-auto border-t border-gray-200">
              <button
                onClick={logout}
                className="w-full flex items-center px-4 py-3 text-sm text-red-600 hover:text-red-700 hover:bg-red-50 rounded-xl transition-all duration-200"
              >
                <LogOut className="w-4 h-4 mr-3" />
                Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
