import React from 'react';
import clsx from 'clsx';

export default function Input({ 
  label, 
  error,
  className = '',
  ...props 
}) {
  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-sm font-medium text-gray-700">
          {label}
        </label>
      )}
      <input
        className={clsx(
          'w-full px-4 py-3 rounded-xl border border-gray-200',
          'focus:ring-2 focus:ring-primary-500 focus:border-transparent',
          'bg-white/50 backdrop-blur-sm shadow-neumorphic',
          'hover:shadow-[4px_4px_8px_#d1d9e6,-4px_-4px_8px_#f8f9fa]',
          'transition-all duration-200',
          'placeholder:text-gray-400',
          error && 'border-red-300 ring-1 ring-red-200 bg-red-50/50',
          className
        )}
        {...props}
      />
      {error && (
        <p className="text-sm text-red-600 mt-1">{error}</p>
      )}
    </div>
  );
}
