import React from 'react';

export default function Card({ children, className = '', title, ...props }) {
  return (
    <div className={`neumorphic p-6 rounded-2xl ${className}`} {...props}>
      {title && (
        <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
          {children.props.icon || children.props.iconComponent}
          <span className="ml-3">{title}</span>
        </h3>
      )}
      {children}
    </div>
  );
}
