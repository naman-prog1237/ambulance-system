import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import AuthPage from './pages/AuthPage';
import VitalsPage from './pages/VitalsPage';
import BedsPage from './pages/BedsPage';
import HospitalsPage from './pages/HospitalsPage';
import RoutePage from './pages/RoutePage';
import SirenPage from './pages/SirenPage';
import AlertsPage from './pages/AlertsPage';
import InsurancePage from './pages/InsurancePage';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import './index.css';

function AppContent() {
  const { user, token } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Router>
        <Toaster position="top-right" />
        <div className="flex h-screen overflow-hidden">
          <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
          
          <div className="flex flex-col flex-1 overflow-hidden lg:ml-64">
            <Navbar onMenuClick={() => setSidebarOpen(true)} />
            
            <main className="flex-1 p-6 overflow-y-auto">
              <Routes>
                <Route path="/" element={token ? <Dashboard /> : <Navigate to="/auth" />} />
                <Route path="/auth" element={<AuthPage />} />
                <Route path="/vitals" element={token ? <VitalsPage /> : <Navigate to="/auth" />} />
                <Route path="/beds" element={token ? <BedsPage /> : <Navigate to="/auth" />} />
                <Route path="/hospitals" element={token ? <HospitalsPage /> : <Navigate to="/auth" />} />
                <Route path="/route" element={token ? <RoutePage /> : <Navigate to="/auth" />} />
                <Route path="/siren" element={token ? <SirenPage /> : <Navigate to="/auth" />} />
                <Route path="/alerts" element={token ? <AlertsPage /> : <Navigate to="/auth" />} />
                <Route path="/insurance" element={token ? <InsurancePage /> : <Navigate to="/auth" />} />
                <Route path="*" element={<Navigate to={token ? "/" : "/auth"} />} />
              </Routes>
            </main>
          </div>
        </div>
      </Router>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
