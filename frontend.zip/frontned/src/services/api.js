import axios from 'axios';
import toast from 'react-hot-toast';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_BASE_URL || 'http://127.0.0.1:8000',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      toast.error('Session expired. Please login again.');
      window.location.href = '/auth';
    } else if (error.response?.status >= 400) {
      toast.error(error.response?.data?.detail || 'Something went wrong');
    }
    return Promise.reject(error);
  }
);

export default api;

// Auth API
export const authAPI = {
  register: (data) => api.post('/api/auth/register', data),
  login: (data) => api.post('/api/auth/login', data),
};

// Vitals API
export const vitalsAPI = {
  updateVitals: (data) => api.post('/api/vitals/update', data),
};

// Beds API
export const bedsAPI = {
  reserveBed: (data) => api.post('/api/beds/reserve', data),
};

// Hospitals API
export const hospitalsAPI = {
  searchHospitals: (data) => api.post('/api/hospitals/search', data),
};

// Route API
export const routeAPI = {
  optimizeRoute: (data) => api.post('/api/route/optimize', data),
};

// Siren API
export const sirenAPI = {
  toggleSiren: (data) => api.post('/api/siren/toggle', data),
};

// Alerts API
export const alertsAPI = {
  sendGuardianSMS: (data) => api.post('/api/alerts/sms', data),
};

// Insurance API
export const insuranceAPI = {
  sendInsuranceAlert: (data) => api.post('/api/insurance/alert', data),
};
