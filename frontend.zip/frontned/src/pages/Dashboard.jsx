import React, { useState, useEffect } from 'react';
import { HeartPulse, Bed, MapPin, AlertTriangle, Shield, Building2 } from 'lucide-react';

import Card from '../components/Card';
import Button from '../components/Button';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    activeAmbulances: 12,
    patientsMonitored: 47,
    bedsReserved: 8,
    alertsSent: 23
  });

  const quickActions = [
    {
      title: 'Update Vitals',
      description: 'Real-time patient monitoring',
      icon: HeartPulse,
      color: 'from-red-400 to-pink-500',
      path: '/vitals'
    },
    {
      title: 'Reserve Bed',
      description: 'Hospital bed management',
      icon: Bed,
      color: 'from-green-400 to-emerald-500',
      path: '/beds'
    },
    {
      title: 'Find Hospital',
      description: 'Nearest facility search',
      icon: Building2,
      color: 'from-blue-400 to-indigo-500',
      path: '/hospitals'
    },
    {
      title: 'Guardian Alert',
      description: 'Emergency notifications',
      icon: AlertTriangle,
      color: 'from-orange-400 to-yellow-500',
      path: '/alerts'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="glass p-8 rounded-2xl">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent mb-4">
          Welcome back, {user?.name}!
        </h1>
        <p className="text-xl text-gray-600">
          Control your ambulance operations from one dashboard.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Object.entries(stats).map(([key, value]) => (
          <Card key={key} className="group hover:scale-[1.02] transition-transform">
            <div className="flex items-center">
              <div className={`p-3 rounded-xl bg-gradient-to-br from-primary-500/10 to-blue-500/10 group-hover:shadow-neumorphic`}>
                {key === 'activeAmbulances' && <HeartPulse className="w-6 h-6 text-primary-600" />}
                {key === 'patientsMonitored' && <Building2 className="w-6 h-6 text-green-600" />}

                {key === 'bedsReserved' && <Bed className="w-6 h-6 text-blue-600" />}
                {key === 'alertsSent' && <AlertTriangle className="w-6 h-6 text-orange-600" />}
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{value}</p>
                <p className="text-sm text-gray-500 capitalize">{key.replace(/([A-Z])/g, ' $1')}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {quickActions.map((action, idx) => (
            <Card key={idx} title={action.title}>
              <action.icon className="w-12 h-12 text-gray-400 mb-4" />
              <p className="text-gray-600 mb-6">{action.description}</p>
              <Button className="w-full">Go to {action.title}</Button>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
