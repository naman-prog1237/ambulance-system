import React, { useState } from 'react';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';
import { RouteIcon, MapPin } from 'lucide-react';
import { routeAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function RoutePage() {
  const [formData, setFormData] = useState({
    ambulance_id: '',
    current_lat: 28.6139,
    current_lon: 77.2090,
    destination_lat: 28.5665,
    destination_lon: 77.1031,
    avoid_traffic: true,
  });
  const [loading, setLoading] = useState(false);
  const [route, setRoute] = useState(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]:
        type === 'checkbox'
          ? checked
          : ['current_lat', 'current_lon', 'destination_lat', 'destination_lon'].includes(name)
          ? Number(value)
          : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.ambulance_id) {
      toast.error('Ambulance ID is required');
      return;
    }

    setLoading(true);
    try {
      const res = await routeAPI.optimizeRoute(formData);
      setRoute(res.data);
      toast.success('Route optimized');
    } catch {
      toast.error('Failed to optimize route');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <RouteIcon className="w-8 h-8 text-indigo-600" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Route Planning</h1>
          <p className="text-gray-600">
            Generate optimized ambulance routes with traffic awareness.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form */}
        <Card className="lg:col-span-1">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Ambulance ID"
              name="ambulance_id"
              value={formData.ambulance_id}
              onChange={handleChange}
              placeholder="AMB-001"
            />
            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Current Latitude"
                name="current_lat"
                type="number"
                step="any"
                value={formData.current_lat}
                onChange={handleChange}
              />
              <Input
                label="Current Longitude"
                name="current_lon"
                type="number"
                step="any"
                value={formData.current_lon}
                onChange={handleChange}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Destination Latitude"
                name="destination_lat"
                type="number"
                step="any"
                value={formData.destination_lat}
                onChange={handleChange}
              />
              <Input
                label="Destination Longitude"
                name="destination_lon"
                type="number"
                step="any"
                value={formData.destination_lon}
                onChange={handleChange}
              />
            </div>
            <label className="inline-flex items-center space-x-2 text-sm text-gray-700">
              <input
                type="checkbox"
                name="avoid_traffic"
                checked={formData.avoid_traffic}
                onChange={handleChange}
                className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
              />
              <span>Avoid traffic if possible</span>
            </label>
            <Button type="submit" loading={loading} className="w-full">
              <MapPin className="w-4 h-4 mr-2" />
              Optimize Route
            </Button>
          </form>
        </Card>

        {/* Result */}
        <Card className="lg:col-span-1">
          {route ? (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Route Summary</h2>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Total Distance</p>
                  <p className="font-semibold">{route.total_distance_km.toFixed(1)} km</p>
                </div>
                <div>
                  <p className="text-gray-500">Estimated Time</p>
                  <p className="font-semibold">{route.estimated_time_minutes} min</p>
                </div>
                <div>
                  <p className="text-gray-500">Traffic Level</p>
                  <p className="font-semibold capitalize">{route.traffic_level}</p>
                </div>
                <div>
                  <p className="text-gray-500">ETA</p>
                  <p className="font-semibold">
                    {new Date(route.estimated_arrival).toLocaleTimeString()}
                  </p>
                </div>
              </div>
              <div className="mt-4 space-y-3 max-h-64 overflow-y-auto">
                {route.route_steps.map((step, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-white shadow-neumorphic flex justify-between text-sm"
                  >
                    <div className="flex items-center space-x-2">
                      <span className="w-6 h-6 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs font-semibold">
                        {idx + 1}
                      </span>
                      <span>{step.instruction}</span>
                    </div>
                    <div className="text-right text-gray-500">
                      <p>{step.distance_km.toFixed(1)} km</p>
                      <p>{step.duration_minutes} min</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-400">
              Submit route details to see optimized steps.
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
