import React, { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import Input from '../components/Input';
import { HeartPulse, Activity } from 'lucide-react';
import { vitalsAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function VitalsPage() {
  const [formData, setFormData] = useState({
    patient_id: '',
    heart_rate: 72,
    oxygen_saturation: 98,
    blood_pressure_sys: 120,
    blood_pressure_dia: 80,
    respiratory_rate: 16,
    body_temperature: 36.6,
    gps_lat: 28.6139,
    gps_lon: 77.2090,
    ecg_reading: [0.1, 0.2, 0.1, -0.1, 0.0]
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [errors, setErrors] = useState({});

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrors({});
    
    try {
      setLoading(true);
      const response = await vitalsAPI.updateVitals(formData);
      setResult(response.data);
      toast.success('Vitals updated & ECG analyzed!');
    } catch (error) {
      toast.error('Failed to update vitals');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <HeartPulse className="w-8 h-8 text-red-500" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Patient Vitals Monitor</h1>
          <p className="text-gray-600">Real-time ECG analysis & anomaly detection</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Update Form */}
        <Card title="📊 Update Patient Vitals" className="lg:col-span-1">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Patient ID"
              name="patient_id"
              value={formData.patient_id}
              onChange={handleChange}
              error={errors.patient_id}
              placeholder="PAT-001"
            />

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Heart Rate (bpm)"
                name="heart_rate"
                type="number"
                value={formData.heart_rate}
                onChange={handleChange}
              />
              <Input
                label="SpO2 (%)"
                name="oxygen_saturation"
                type="number"
                value={formData.oxygen_saturation}
                onChange={handleChange}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Systolic BP"
                name="blood_pressure_sys"
                type="number"
                value={formData.blood_pressure_sys}
                onChange={handleChange}
              />
              <Input
                label="Diastolic BP"
                name="blood_pressure_dia"
                type="number"
                value={formData.blood_pressure_dia}
                onChange={handleChange}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Respiratory Rate"
                name="respiratory_rate"
                type="number"
                value={formData.respiratory_rate}
                onChange={handleChange}
              />
              <Input
                label="Temperature (°C)"
                name="body_temperature"
                type="number"
                step="0.1"
                value={formData.body_temperature}
                onChange={handleChange}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="GPS Latitude"
                name="gps_lat"
                type="number"
                step="any"
                value={formData.gps_lat}
                onChange={handleChange}
              />
              <Input
                label="GPS Longitude"
                name="gps_lon"
                type="number"
                step="any"
                value={formData.gps_lon}
                onChange={handleChange}
              />
            </div>

            <Button type="submit" loading={loading} className="w-full">
              🔬 Analyze ECG & Update Vitals
            </Button>
          </form>
        </Card>

        {/* Results */}
        <Card title="🎯 ECG Analysis Result" className="lg:col-span-1">
          {result ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Anomaly Detected:</span>
                  <span className={result.is_anomaly ? 'text-red-600 font-semibold' : 'text-green-600 font-semibold'}>
                    {result.is_anomaly ? '🚨 YES' : '✅ NO'}
                  </span>
                </div>
                {result.anomaly_type && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Type:</span>
                    <span className="text-orange-600 font-semibold">{result.anomaly_type}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-gray-600">Confidence:</span>
                  <span className="text-blue-600 font-bold">
                    {(result.confidence_score * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Heart Rate:</span>
                  <span className="text-gray-900 font-semibold">{result.heart_rate} bpm</span>
                </div>
              </div>
              <div className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl border border-yellow-200">
                <p className="text-sm font-semibold text-gray-900 mb-2">💡 Recommendation:</p>
                <p className="text-sm text-gray-700">{result.recommendation}</p>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-400">
              <Activity className="w-16 h-16 animate-pulse mr-4" />
              <span className="text-lg">Submit vitals to see ECG analysis</span>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
