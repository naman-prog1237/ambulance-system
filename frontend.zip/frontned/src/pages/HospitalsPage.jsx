import React, { useState } from 'react';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';
import DataTable from '../components/DataTable';
import { Building2, MapPin } from 'lucide-react';
import { hospitalsAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function HospitalsPage() {
  const [formData, setFormData] = useState({
    latitude: 28.6139,
    longitude: 77.2090,
    radius_km: 10,
    bed_type: '',
    specialization: '',
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]:
        name === 'latitude' || name === 'longitude' || name === 'radius_km'
          ? Number(value)
          : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.latitude || !formData.longitude) {
      toast.error('Latitude and longitude are required');
      return;
    }

    const payload = {
      latitude: formData.latitude,
      longitude: formData.longitude,
      radius_km: formData.radius_km || 10,
      bed_type: formData.bed_type || null,
      specialization: formData.specialization
        ? formData.specialization.split(',').map((s) => s.trim())
        : null,
    };

    setLoading(true);
    try {
      const res = await hospitalsAPI.searchHospitals(payload);
      setResult(res.data);
      toast.success('Hospitals loaded');
    } catch {
      toast.error('Failed to search hospitals');
    } finally {
      setLoading(false);
    }
  };

  const columns = [
    { header: 'Name', key: 'name' },
    { header: 'Distance (km)', key: 'distance_km', render: (row) => row.distance_km.toFixed(1) },
    { header: 'ICU', key: 'icu_beds_available' },
    { header: 'General', key: 'general_beds_available' },
    { header: 'Emergency', key: 'emergency_beds_available' },
    {
      header: 'Specializations',
      key: 'specializations',
      render: (row) => row.specializations.join(', '),
    },
    { header: 'Phone', key: 'phone' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Building2 className="w-8 h-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Hospital Management</h1>
          <p className="text-gray-600">
            Search nearby hospitals with available beds and specializations.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Form */}
        <Card className="lg:col-span-1">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Latitude"
                name="latitude"
                type="number"
                step="any"
                value={formData.latitude}
                onChange={handleChange}
              />
              <Input
                label="Longitude"
                name="longitude"
                type="number"
                step="any"
                value={formData.longitude}
                onChange={handleChange}
              />
            </div>
            <Input
              label="Radius (km)"
              name="radius_km"
              type="number"
              value={formData.radius_km}
              onChange={handleChange}
            />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bed Type (optional)
              </label>
              <select
                name="bed_type"
                value={formData.bed_type}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 shadow-neumorphic focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="">Any</option>
                <option value="ICU">ICU</option>
                <option value="general">General</option>
                <option value="emergency">Emergency</option>
              </select>
            </div>
            <Input
              label="Specializations (comma separated)"
              name="specialization"
              value={formData.specialization}
              onChange={handleChange}
              placeholder="cardiology, trauma, neurology"
            />
            <Button type="submit" loading={loading} className="w-full">
              <MapPin className="w-4 h-4 mr-2" />
              Search Hospitals
            </Button>
          </form>
        </Card>

        {/* Table */}
        <div className="lg:col-span-2">
          <DataTable
            columns={columns}
            data={result?.hospitals || []}
            loading={loading}
            pagination={false}
          />
          {result && (
            <p className="mt-3 text-sm text-gray-600">
              Total hospitals found: <span className="font-semibold">{result.total_found}</span>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
