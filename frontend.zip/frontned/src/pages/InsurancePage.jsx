import React, { useState } from 'react';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';
import { Shield, FileText } from 'lucide-react';
import { insuranceAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function InsurancePage() {
  const [formData, setFormData] = useState({
    patient_id: '',
    hospital_id: '',
    estimated_cost: 50000,
    insurance_provider: '',
  });
  const [loading, setLoading] = useState(false);
  const [alertData, setAlertData] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'estimated_cost' ? Number(value) : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.patient_id || !formData.hospital_id) {
      toast.error('Patient ID and Hospital ID are required');
      return;
    }

    setLoading(true);
    try {
      const res = await insuranceAPI.sendInsuranceAlert({
        patient_id: formData.patient_id,
        hospital_id: formData.hospital_id,
        estimated_cost: formData.estimated_cost,
        insurance_provider: formData.insurance_provider || null,
      });
      setAlertData(res.data);
      toast.success('Insurance alert created');
    } catch {
      toast.error('Failed to send insurance alert');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Shield className="w-8 h-8 text-emerald-600" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Insurance Pre‑Authorization</h1>
          <p className="text-gray-600">
            Notify insurers and estimate coverage for emergency admissions.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form */}
        <Card className="lg:col-span-1">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Patient ID"
              name="patient_id"
              value={formData.patient_id}
              onChange={handleChange}
              placeholder="PAT-001"
            />
            <Input
              label="Hospital ID"
              name="hospital_id"
              value={formData.hospital_id}
              onChange={handleChange}
              placeholder="HOSP-001"
            />
            <Input
              label="Estimated Treatment Cost"
              name="estimated_cost"
              type="number"
              value={formData.estimated_cost}
              onChange={handleChange}
            />
            <Input
              label="Insurance Provider (optional)"
              name="insurance_provider"
              value={formData.insurance_provider}
              onChange={handleChange}
              placeholder="XYZ Health Insurance"
            />
            <Button type="submit" loading={loading} className="w-full">
              <FileText className="w-4 h-4 mr-2" />
              Send Insurance Alert
            </Button>
          </form>
        </Card>

        {/* Result */}
        <Card className="lg:col-span-1">
          {alertData ? (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Coverage Summary</h2>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Alert ID</p>
                  <p className="font-semibold">{alertData.alert_id}</p>
                </div>
                <div>
                  <p className="text-gray-500">Patient</p>
                  <p className="font-semibold">{alertData.patient_id}</p>
                </div>
                <div>
                  <p className="text-gray-500">Coverage Eligible</p>
                  <p
                    className={`font-semibold ${
                      alertData.coverage_eligible ? 'text-emerald-600' : 'text-red-600'
                    }`}
                  >
                    {alertData.coverage_eligible ? 'YES' : 'NO'}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Estimated Coverage</p>
                  <p className="font-semibold">₹ {alertData.estimated_coverage}</p>
                </div>
                <div>
                  <p className="text-gray-500">Patient Liability</p>
                  <p className="font-semibold">₹ {alertData.patient_liability}</p>
                </div>
                <div>
                  <p className="text-gray-500">Status</p>
                  <p className="font-semibold capitalize">
                    {alertData.status || 'pending'}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Created At</p>
                  <p className="font-semibold">
                    {new Date(alertData.created_at).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-400">
              Submit an insurance alert to view coverage estimation.
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
