# backend/apis/pathway_generator.py
"""
Patient Care Pathway Generation API
Generates step-by-step clinical pathways using RAG + LLM
"""

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthCredentials, HTTPBearer
from typing import Optional
from datetime import datetime
import logging
import json
import os

from models import (
    PatientCarePathwayRequest,
    PatientCarePathway,
    PathwayUpdateRequest,
    PathwayAction
)
from auth import auth_service, rbac
from config import settings
from services.rag_service import get_rag_service
from services.llm_service import get_llm_service

logger = logging.getLogger(__name__)
security = HTTPBearer()

router = APIRouter(prefix="/api/pathways", tags=["Patient Care Pathways"])

# Initialize services
rag_service = get_rag_service()
llm_service = get_llm_service(rag_service)

# In-memory pathway storage (in production, use database)
pathway_store: dict = {}


@router.post(
    "/generate",
    response_model=PatientCarePathway,
    summary="Generate Patient Care Pathway",
    description="""
    Generate a comprehensive step-by-step patient care pathway using:
    - Patient vital signs and symptoms
    - Medical history and medications
    - Retrieved medical guidelines (RAG)
    - LLM-powered decision support
    
    Returns: Structured pathway with ranked actions and confidence scores
    """
)
async def generate_pathway(
    request: PatientCarePathwayRequest,
    credentials: HTTPAuthCredentials = Depends(security)
) -> PatientCarePathway:
    """
    Generate patient care pathway
    
    Args:
        request: Pathway generation request with vitals and symptoms
        credentials: User authentication credentials
        
    Returns:
        Generated care pathway with actions and confidence scores
        
    Raises:
        HTTPException: If generation fails or user unauthorized
    """
    try:
        # Authenticate user
        user = auth_service.get_current_user(credentials.credentials)
        logger.info(f"User {user['user_id']} requesting pathway generation for patient {request.patient_id}")
        
        # Extract condition from symptoms
        condition = None
        if request.symptoms and request.symptoms.symptoms:
            condition = request.symptoms.symptoms[0]  # Primary symptom as condition hint
        
        # Generate pathway using LLM + RAG
        pathway_data = llm_service.generate_care_pathway(
            vitals=request.vitals.dict(),
            symptoms=request.symptoms.dict(),
            medical_history=request.symptoms.medical_history or [],
            age=25,  # In production, get from patient DB
            condition=condition
        )
        
        # Enhance with medical file analysis if provided
        if request.medical_files:
            pathway_data = await _analyze_medical_files(
                request.medical_files,
                pathway_data
            )
        
        # Generate pathway ID
        from uuid import uuid4
        pathway_id = str(uuid4())
        
        # Create response
        response = PatientCarePathway(
            pathway_id=pathway_id,
            patient_id=request.patient_id,
            generated_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            overall_confidence=pathway_data.get("overall_confidence", 0.7),
            severity_assessment=pathway_data.get("severity", "stable"),
            actions=[
                PathwayAction(
                    step_number=action.get("step_number"),
                    action=action.get("action"),
                    urgency=action.get("urgency", "medium"),
                    time_frame_minutes=action.get("time_frame_minutes", 10),
                    responsible_party=action.get("responsible_party", "Medical Staff"),
                    prerequisites=action.get("prerequisites"),
                    monitoring_parameters=action.get("monitoring_parameters")
                )
                for action in pathway_data.get("actions", [])
            ],
            clinical_summary=pathway_data.get("clinical_summary", "Clinical assessment"),
            rag_sources=pathway_data.get("rag_sources", []),
            next_review_minutes=pathway_data.get("next_review_minutes", 5)
        )
        
        # Store pathway
        pathway_store[pathway_id] = response.dict()
        
        # Cache pathway
        _cache_pathway(pathway_id, response)
        
        logger.info(f"Generated pathway {pathway_id} with confidence {response.overall_confidence:.2f}")
        return response
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating pathway: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate pathway: {str(e)}"
        )


@router.post(
    "/{pathway_id}/update",
    response_model=PatientCarePathway,
    summary="Update Pathway with New Vitals",
    description="""
    Update an existing pathway based on new patient vitals.
    This re-evaluates the care plan and may modify actions or urgency levels.
    """
)
async def update_pathway(
    pathway_id: str,
    request: PathwayUpdateRequest,
    credentials: HTTPAuthCredentials = Depends(security)
) -> PatientCarePathway:
    """
    Update pathway with new vitals
    
    Args:
        pathway_id: ID of pathway to update
        request: Update request with new vitals
        credentials: User authentication
        
    Returns:
        Updated care pathway
    """
    try:
        # Authenticate
        user = auth_service.get_current_user(credentials.credentials)
        
        # Get existing pathway
        if pathway_id not in pathway_store:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Pathway {pathway_id} not found"
            )
        
        existing_pathway = pathway_store[pathway_id]
        
        # Re-generate with new vitals
        condition = None
        if request.new_symptoms:
            condition = request.new_symptoms.symptoms[0] if request.new_symptoms.symptoms else None
        
        pathway_data = llm_service.generate_care_pathway(
            vitals=request.new_vitals.dict(),
            symptoms=request.new_symptoms.dict() if request.new_symptoms else {},
            medical_history=request.new_symptoms.medical_history if request.new_symptoms else [],
            age=25,
            condition=condition
        )
        
        # Create updated response
        updated_response = PatientCarePathway(
            pathway_id=pathway_id,
            patient_id=request.patient_id,
            generated_at=datetime.fromisoformat(existing_pathway["generated_at"]),
            updated_at=datetime.utcnow(),
            overall_confidence=pathway_data.get("overall_confidence", 0.7),
            severity_assessment=pathway_data.get("severity", "stable"),
            actions=[
                PathwayAction(
                    step_number=action.get("step_number"),
                    action=action.get("action"),
                    urgency=action.get("urgency", "medium"),
                    time_frame_minutes=action.get("time_frame_minutes", 10),
                    responsible_party=action.get("responsible_party", "Medical Staff"),
                    prerequisites=action.get("prerequisites"),
                    monitoring_parameters=action.get("monitoring_parameters")
                )
                for action in pathway_data.get("actions", [])
            ],
            clinical_summary=pathway_data.get("clinical_summary", "Clinical assessment"),
            rag_sources=pathway_data.get("rag_sources", []),
            next_review_minutes=pathway_data.get("next_review_minutes", 5)
        )
        
        # Update store and cache
        pathway_store[pathway_id] = updated_response.dict()
        _cache_pathway(pathway_id, updated_response)
        
        logger.info(f"Updated pathway {pathway_id}")
        return updated_response
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating pathway: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update pathway: {str(e)}"
        )


@router.get(
    "/{pathway_id}",
    response_model=PatientCarePathway,
    summary="Get Pathway",
    description="Retrieve a generated care pathway by ID"
)
async def get_pathway(
    pathway_id: str,
    credentials: HTTPAuthCredentials = Depends(security)
) -> PatientCarePathway:
    """
    Get pathway by ID
    
    Args:
        pathway_id: ID of pathway to retrieve
        credentials: User authentication
        
    Returns:
        Care pathway
    """
    try:
        user = auth_service.get_current_user(credentials.credentials)
        
        # Check cache first
        cached = _get_cached_pathway(pathway_id)
        if cached:
            return cached
        
        if pathway_id not in pathway_store:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Pathway {pathway_id} not found"
            )
        
        return PatientCarePathway(**pathway_store[pathway_id])
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving pathway: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve pathway: {str(e)}"
        )


@router.get(
    "/patient/{patient_id}",
    summary="Get Patient Pathways",
    description="Retrieve all pathways for a patient"
)
async def get_patient_pathways(
    patient_id: str,
    credentials: HTTPAuthCredentials = Depends(security)
) -> dict:
    """
    Get all pathways for a patient
    
    Args:
        patient_id: Patient ID
        credentials: User authentication
        
    Returns:
        List of patient's pathways
    """
    try:
        user = auth_service.get_current_user(credentials.credentials)
        
        patient_pathways = [
            pathway for pathway in pathway_store.values()
            if pathway.get("patient_id") == patient_id
        ]
        
        return {
            "patient_id": patient_id,
            "total_pathways": len(patient_pathways),
            "pathways": patient_pathways
        }
    
    except Exception as e:
        logger.error(f"Error retrieving patient pathways: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve pathways: {str(e)}"
        )


@router.post(
    "/retrieve-guidelines",
    summary="Retrieve Medical Guidelines",
    description="Search and retrieve relevant medical guidelines for a condition"
)
async def retrieve_guidelines(
    query: str,
    condition: Optional[str] = None,
    top_k: int = 5,
    credentials: HTTPAuthCredentials = Depends(security)
) -> dict:
    """
    Retrieve medical guidelines using RAG
    
    Args:
        query: Search query
        condition: Specific condition filter
        top_k: Number of results
        credentials: User authentication
        
    Returns:
        Retrieved guidelines
    """
    try:
        user = auth_service.get_current_user(credentials.credentials)
        
        guidelines = rag_service.retrieve_guidelines(
            query=query,
            condition=condition,
            top_k=top_k
        )
        
        return {
            "query": query,
            "condition": condition,
            "guidelines_found": len(guidelines),
            "guidelines": guidelines
        }
    
    except Exception as e:
        logger.error(f"Error retrieving guidelines: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve guidelines: {str(e)}"
        )


# ==================== HELPER FUNCTIONS ====================

async def _analyze_medical_files(
    file_paths: list,
    pathway_data: dict
) -> dict:
    """
    Analyze uploaded medical files and enhance pathway
    
    Args:
        file_paths: List of file paths
        pathway_data: Current pathway data
        
    Returns:
        Enhanced pathway data
    """
    try:
        # In production, parse PDFs, reports, etc.
        # For now, log that files were considered
        logger.info(f"Analyzing {len(file_paths)} medical files for pathway enhancement")
        
        # Add note to clinical summary
        pathway_data["clinical_summary"] += f"\n[Note: {len(file_paths)} supporting documents reviewed]"
        
        return pathway_data
    except Exception as e:
        logger.warning(f"Error analyzing medical files: {e}")
        return pathway_data


def _cache_pathway(pathway_id: str, pathway: PatientCarePathway):
    """Cache pathway to local storage"""
    try:
        cache_dir = os.path.join(settings.OFFLINE_CACHE_DIR, "pathways")
        os.makedirs(cache_dir, exist_ok=True)
        
        cache_file = os.path.join(cache_dir, f"{pathway_id}.json")
        with open(cache_file, 'w') as f:
            json.dump(pathway.dict(), f, indent=2, default=str)
    except Exception as e:
        logger.warning(f"Error caching pathway: {e}")


def _get_cached_pathway(pathway_id: str) -> Optional[PatientCarePathway]:
    """Get pathway from cache"""
    try:
        cache_file = os.path.join(
            settings.OFFLINE_CACHE_DIR,
            "pathways",
            f"{pathway_id}.json"
        )
        
        if os.path.exists(cache_file):
            with open(cache_file, 'r') as f:
                data = json.load(f)
                return PatientCarePathway(**data)
    except Exception as e:
        logger.warning(f"Error loading cached pathway: {e}")
    
    return None
