# backend/rag_service.py
"""
RAG (Retrieval Augmented Generation) Service for Medical Guidelines
Handles document retrieval from vector databases
"""

from typing import List, Dict, Optional, Any
from langchain.text_splitter import RecursiveCharacterTextSplitter


from langchain_community.embeddings import OpenAIEmbeddings, HuggingFaceEmbeddings
from langchain_community.vectorstores import Milvus, Pinecone, Weaviate
import logging
from config import settings
from datetime import datetime
import json
import os

logger = logging.getLogger(__name__)

class RAGService:
    """
    Retrieval Augmented Generation service for fetching medical guidelines
    """

    def __init__(self):
        """Initialize RAG service with vector database and embeddings"""
        self.vector_db = None
        self.embeddings = None
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.RAG_CHUNK_SIZE,
            chunk_overlap=settings.RAG_CHUNK_OVERLAP,
            separators=["\n\n", "\n", " ", ""]
        )

        self._initialize_embeddings()
        self._initialize_vector_db()
        self._load_medical_guidelines()

    def _initialize_embeddings(self):
        try:
            # existing embedding init code (keep as is)
            logger.info("Embeddings initialized successfully (HuggingFace)")
        except Exception as e:
            logger.error(f"Error initializing embeddings: {e}")
        # no 'raise' here

    def _initialize_vector_db(self):
        """Initialize vector database based on configuration"""
        try:
            if settings.VECTOR_DB_TYPE == "milvus":
                # Milvus requires pymilvus and running Milvus server
                self.vector_db = Milvus(
                    embedding_function=self.embeddings,
                    collection_name="medical_guidelines",
                    connection_args={
                        "host": settings.MILVUS_HOST,
                        "port": settings.MILVUS_PORT
                    }
                )
            elif settings.VECTOR_DB_TYPE == "pinecone":
                self.vector_db = Pinecone(
                    index_name="medical-guidelines",
                    embedding_function=self.embeddings,
                    namespace="pathways"
                )
            elif settings.VECTOR_DB_TYPE == "weaviate":
                self.vector_db = Weaviate(
                    client=None,  # Initialize with URL if needed
                    index_name="MedicalGuidelines",
                    text_key="content",
                    embedding_function=self.embeddings
                )

            logger.info(f"Vector DB ({settings.VECTOR_DB_TYPE}) initialized")
        except Exception as e:
            logger.warning(f"Vector DB initialization failed: {e}. Using local cache.")
            self.vector_db = None

    def _load_medical_guidelines(self):
        """Load medical guidelines into vector database"""
        try:
            guidelines_path = os.path.join(
                settings.OFFLINE_CACHE_DIR,
                "medical_guidelines.json"
            )

            if not os.path.exists(guidelines_path):
                logger.warning("Medical guidelines file not found. Creating sample...")
                self._create_sample_guidelines(guidelines_path)

            with open(guidelines_path, 'r') as f:
                guidelines = json.load(f)

            # Add guidelines to vector DB
            if self.vector_db is not None:
                for guideline in guidelines.get("guidelines", []):
                    chunks = self.text_splitter.split_text(
                        guideline.get("content", "")
                    )

                    # Add to vector DB with metadata
                    for chunk in chunks:
                        self.vector_db.add_texts(
                            [chunk],
                            metadatas=[{
                                "guideline_id": guideline.get("id"),
                                "condition": guideline.get("condition"),
                                "source": guideline.get("source")
                            }]
                        )

            logger.info(f"Loaded {len(guidelines.get('guidelines', []))} medical guidelines")
        except Exception as e:
            logger.error(f"Error loading medical guidelines: {e}")

    def _create_sample_guidelines(self, path: str):
        """Create sample medical guidelines for testing"""
        sample_guidelines = {
            "guidelines": [
                {
                    "id": "hypertension_001",
                    "condition": "Hypertension / High Blood Pressure",
                    "source": "WHO Guidelines 2023",
                    "content": """
HYPERTENSION MANAGEMENT:
1. Initial Assessment:
   - Measure blood pressure multiple times
   - Check for end-organ damage
   - Assess cardiovascular risk factors

2. Mild Hypertension (140-159 / 90-99 mmHg):
   - Lifestyle modifications for 3-6 months
   - Repeat measurement at each visit

3. Moderate to Severe (≥160/100 mmHg):
   - Initiate antihypertensive therapy immediately
   - Target BP <140/90 mmHg in most patients

4. First-Line Medications:
   - ACE inhibitors or ARBs
   - Beta-blockers
   - Calcium channel blockers
   - Thiazide diuretics

5. Monitoring:
   - Home BP monitoring
   - Follow-up visits every 4 weeks initially
   - ECG if symptoms of LVH
"""
                },
                {
                    "id": "chest_pain_001",
                    "condition": "Acute Chest Pain / Suspected ACS",
                    "source": "ACC/AHA Guidelines 2023",
                    "content": """
ACUTE CORONARY SYNDROME MANAGEMENT:

1. Immediate Actions (First 10 minutes):
   - Obtain 12-lead ECG within 10 minutes
   - Establish IV access
   - Administer oxygen if SpO2 <94%
   - Administer aspirin 325-500mg

2. Risk Stratification:
   - TIMI Score assessment
   - Troponin levels
   - ECG changes

3. Medications:
   - Dual antiplatelet therapy
   - Anticoagulation
   - Beta-blockers
   - ACE inhibitors
   - Statins
"""
                }
            ]
        }

        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            json.dump(sample_guidelines, f, indent=2)

        logger.info(f"Created sample guidelines at {path}")

    def retrieve_guidelines(
        self,
        query: str,
        condition: Optional[str] = None,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Retrieve relevant medical guidelines based on query

        Args:
            query: Search query (symptoms, condition keywords)
            condition: Specific medical condition filter
            top_k: Number of top results to return

        Returns:
            List of relevant guideline chunks with metadata
        """
        try:
            if self.vector_db is None:
                logger.warning("Vector DB not available, using local cache")
                return self._retrieve_from_local_cache(query, condition, top_k)

            # Search vector DB
            search_query = query
            if condition:
                search_query += f" {condition}"

            results = self.vector_db.similarity_search_with_score(
                search_query,
                k=top_k
            )

            retrieved_guidelines = []
            for doc, score in results:
                retrieved_guidelines.append({
                    "content": doc.page_content,
                    "metadata": doc.metadata,
                    "relevance_score": float(score)
                })

            logger.info(f"Retrieved {len(retrieved_guidelines)} guidelines for: {query}")
            return retrieved_guidelines

        except Exception as e:
            logger.error(f"Error retrieving guidelines: {e}")
            return self._retrieve_from_local_cache(query, condition, top_k)

    def _retrieve_from_local_cache(
        self,
        query: str,
        condition: Optional[str] = None,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Retrieve guidelines from local cache file

        Args:
            query: Search query
            condition: Specific condition filter
            top_k: Number of results

        Returns:
            List of guidelines from cache
        """
        try:
            guidelines_path = os.path.join(
                settings.OFFLINE_CACHE_DIR,
                "medical_guidelines.json"
            )

            if not os.path.exists(guidelines_path):
                return []

            with open(guidelines_path, 'r') as f:
                data = json.load(f)

            results = []
            query_lower = query.lower()

            for guideline in data.get("guidelines", []):
                # Simple keyword matching
                if (query_lower in guideline.get("condition", "").lower() or
                    query_lower in guideline.get("content", "").lower()):
                    if condition is None or condition.lower() in guideline.get("condition", "").lower():
                        results.append({
                            "content": guideline.get("content"),
                            "metadata": {
                                "guideline_id": guideline.get("id"),
                                "condition": guideline.get("condition"),
                                "source": guideline.get("source")
                            },
                            "relevance_score": 0.8  # Default score for local cache
                        })

            return results[:top_k]

        except Exception as e:
            logger.error(f"Error retrieving from local cache: {e}")
            return []

    def add_custom_guidelines(self, guidelines: List[Dict[str, str]]):
        """
        Add custom medical guidelines

        Args:
            guidelines: List of guideline dictionaries with 'condition' and 'content'
        """
        try:
            guidelines_path = os.path.join(
                settings.OFFLINE_CACHE_DIR,
                "medical_guidelines.json"
            )

            # Load existing guidelines
            if os.path.exists(guidelines_path):
                with open(guidelines_path, 'r') as f:
                    existing = json.load(f)
            else:
                existing = {"guidelines": []}

            # Add new guidelines
            for guideline in guidelines:
                new_guideline = {
                    "id": f"custom_{len(existing['guidelines'])}",
                    "condition": guideline.get("condition"),
                    "source": "Custom - Local",
                    "content": guideline.get("content"),
                    "added_at": datetime.utcnow().isoformat()
                }

                existing["guidelines"].append(new_guideline)

            # Add to vector DB if available
            if self.vector_db is not None:
                chunks = self.text_splitter.split_text(new_guideline["content"])
                for chunk in chunks:
                    self.vector_db.add_texts(
                        [chunk],
                        metadatas=[{
                            "guideline_id": new_guideline["id"],
                            "condition": new_guideline["condition"],
                            "source": new_guideline["source"]
                        }]
                    )

            # Save updated guidelines
            with open(guidelines_path, 'w') as f:
                json.dump(existing, f, indent=2)

            logger.info(f"Added {len(guidelines)} custom guidelines")

        except Exception as e:
            logger.error(f"Error adding custom guidelines: {e}")


# Singleton instance
_rag_service = None

def get_rag_service() -> RAGService:
    """Get or create RAG service singleton"""
    global _rag_service
    if _rag_service is None:
        _rag_service = RAGService()
    return _rag_service
