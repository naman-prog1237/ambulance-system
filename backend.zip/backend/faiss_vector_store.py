import faiss
import numpy as np
from typing import List, Tuple
import pickle
import os


class FAISSVectorStore:
    """Wrapper for FAISS vector database"""
    
    def __init__(self, dimension: int = 384):
        self.dimension = dimension
        self.index = faiss.IndexFlatL2(dimension)
        self.documents = []
        self.metadata = []
    
    def add(self, embeddings: np.ndarray, docs: List, metadata: List):
        """Add embeddings and documents"""
        self.index.add(embeddings.astype('float32'))
        self.documents.extend(docs)
        self.metadata.extend(metadata)
    
    def search(self, query_embedding: np.ndarray, k: int = 5) -> Tuple[List, List[float]]:
        """Search for top k similar documents"""
        query_embedding = query_embedding.astype('float32').reshape(1, -1)
        distances, indices = self.index.search(query_embedding, k)
        
        results = [self.documents[i] for i in indices[0] if i < len(self.documents)]
        scores = [1/(1+d) for d in distances[0]]
        
        return results, scores
    
    def save(self, path: str):
        """Save index to disk"""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        faiss.write_index(self.index, path + ".index")
        with open(path + ".meta", "wb") as f:
            pickle.dump({"docs": self.documents, "meta": self.metadata}, f)
    
    def load(self, path: str):
        """Load index from disk"""
        if os.path.exists(path + ".index"):
            self.index = faiss.read_index(path + ".index")
            with open(path + ".meta", "rb") as f:
                data = pickle.load(f)
                self.documents = data["docs"]
                self.metadata = data["meta"]
