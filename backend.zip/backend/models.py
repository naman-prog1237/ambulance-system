# backend/models.py
"""
Pydantic models for API requests and responses
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

# ==================== ENUMS ====================

class UserRole(str, Enum):
    """User roles in the system"""
    ADMIN = "admin"
    DOCTOR = "doctor"
    PARAMEDIC = "paramedic"
    HOSPITAL_STAFF = "hospital_staff"
    PATIENT = "patient"

class AmbulanceStatus(str, Enum):
    """Ambulance operational status"""
    IDLE = "idle"
    ON_DUTY = "on_duty"
    RESPONDING = "responding"
    IN_TRANSIT = "in_transit"
    AT_HOSPITAL = "at_hospital"
    MAINTENANCE = "maintenance"

class VitalsStatus(str, Enum):
    """Patient vitals status"""
    NORMAL = "normal"
    CAUTION = "caution"
    CRITICAL = "critical"
    UNKNOWN = "unknown"

# ==================== AUTHENTICATION ====================

class TokenRequest(BaseModel):
    """User login request"""
    email: str = Field(..., description="User email")
    password: str = Field(..., description="User password")

class TokenResponse(BaseModel):
    """JWT token response"""
    access_token: str = Field(..., description="JWT access token")
    token_type: str = "bearer"
    expires_in: int = Field(..., description="Token expiry in seconds")

# ==================== USER MODELS ====================

class UserCreate(BaseModel):
    """User creation request"""
    name: str = Field(..., description="User full name")
    email: str = Field(..., description="User email")
    password: str = Field(..., description="User password")
    phone: str = Field(..., description="User phone number")
    role: UserRole = Field(..., description="User role")
    hospital_id: Optional[str] = Field(None, description="Hospital ID if applicable")

class UserResponse(BaseModel):
    """User response model"""
    id: str
    name: str
    email: str
    phone: str
    role: UserRole
    created_at: datetime

# ==================== VITALS & PATIENT DATA ====================

class PatientVitals(BaseModel):
    """Real-time patient vitals from IoT devices"""
    patient_id: str = Field(..., description="Patient ID")
    ecg_reading: List[float] = Field(..., description="ECG values (mV)")
    heart_rate: int = Field(..., ge=30, le=200, description="Heart rate (bpm)")
    oxygen_saturation: float = Field(..., ge=0, le=100, description="SpO2 percentage")
    blood_pressure_sys: int = Field(..., ge=50, le=250, description="Systolic BP (mmHg)")
    blood_pressure_dia: int = Field(..., ge=30, le=150, description="Diastolic BP (mmHg)")
    respiratory_rate: int = Field(..., ge=8, le=40, description="Respiratory rate (breaths/min)")
    body_temperature: float = Field(..., ge=35, le=42, description="Body temperature (°C)")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    gps_lat: float = Field(..., description="GPS latitude")
    gps_lon: float = Field(..., description="GPS longitude")

class PatientSymptoms(BaseModel):
    """Patient reported symptoms"""
    patient_id: str = Field(..., description="Patient ID")
    symptoms: List[str] = Field(..., description="List of reported symptoms")
    severity: int = Field(..., ge=1, le=10, description="Pain/symptom severity (1-10)")
    duration_minutes: int = Field(..., description="Duration of symptoms in minutes")
    medical_history: Optional[List[str]] = Field(None, description="Relevant medical history")
    current_medications: Optional[List[str]] = Field(None, description="Current medications")
    allergies: Optional[List[str]] = Field(None, description="Known allergies")

class PatientData(BaseModel):
    """Complete patient data"""
    id: str
    name: str
    age: int
    gender: str
    blood_group: str
    phone: str
    emergency_contact: str
    medical_history: List[str]
    current_medications: List[str]
    allergies: List[str]
    created_at: datetime

# ==================== ECG & ANOMALY DETECTION ====================

class ECGAnalysisResult(BaseModel):
    """ECG anomaly detection result"""
    patient_id: str
    is_anomaly: bool = Field(..., description="Whether anomaly detected")
    anomaly_type: Optional[str] = Field(None, description="Type of anomaly (e.g., arrhythmia)")
    confidence_score: float = Field(..., ge=0, le=1, description="Confidence of detection")
    heart_rate: int
    heart_rate_variability: float = Field(..., description="HRV in ms")
    recommendation: str = Field(..., description="Clinical recommendation")
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# ==================== HOSPITAL & BED MANAGEMENT ====================

class BedAvailability(BaseModel):
    """Bed availability information"""
    hospital_id: str = Field(..., description="Hospital ID")
    total_beds: int = Field(..., description="Total beds available")
    icu_beds: int = Field(..., description="ICU beds available")
    general_beds: int = Field(..., description="General beds available")
    emergency_beds: int = Field(..., description="Emergency beds available")

class BedReservationRequest(BaseModel):
    """Bed reservation request"""
    patient_id: str = Field(..., description="Patient ID")
    hospital_id: str = Field(..., description="Hospital ID")
    bed_type: str = Field(..., description="Type of bed (ICU, general, emergency)")
    reason: str = Field(..., description="Reason for admission")
    estimated_stay_hours: int = Field(..., description="Estimated stay duration")

class BedReservationResponse(BaseModel):
    """Bed reservation response"""
    reservation_id: str
    patient_id: str
    hospital_id: str
    bed_id: str
    bed_type: str
    reserved_at: datetime
    expected_arrival: datetime
    status: str = "confirmed"

# ==================== HOSPITAL SEARCH ====================

class HospitalSearchRequest(BaseModel):
    """Near-hospital search request"""
    latitude: float = Field(..., description="Current latitude")
    longitude: float = Field(..., description="Current longitude")
    radius_km: int = Field(default=10, ge=1, le=50, description="Search radius in kilometers")
    bed_type: Optional[str] = Field(None, description="Required bed type")
    specialization: Optional[List[str]] = Field(None, description="Required specializations")

class HospitalInfo(BaseModel):
    """Hospital information"""
    id: str
    name: str
    latitude: float
    longitude: float
    distance_km: float = Field(..., description="Distance from current location")
    icu_beds_available: int
    general_beds_available: int
    emergency_beds_available: int
    phone: str
    specializations: List[str]
    emergency_contact: str
    average_response_time_minutes: Optional[float] = None

class HospitalSearchResponse(BaseModel):
    """Hospital search response"""
    hospitals: List[HospitalInfo] = Field(..., description="List of nearby hospitals")
    total_found: int

# ==================== ROUTE PLANNING ====================

class RouteOptimizationRequest(BaseModel):
    """Route optimization request"""
    ambulance_id: str = Field(..., description="Ambulance ID")
    current_lat: float = Field(..., description="Current latitude")
    current_lon: float = Field(..., description="Current longitude")
    destination_lat: float = Field(..., description="Destination latitude")
    destination_lon: float = Field(..., description="Destination longitude")
    avoid_traffic: bool = Field(default=True, description="Avoid traffic if possible")

class RouteStep(BaseModel):
    """Single route step"""
    instruction: str
    distance_km: float
    duration_minutes: int
    latitude: float
    longitude: float

class RouteOptimizationResponse(BaseModel):
    """Route optimization response"""
    ambulance_id: str
    total_distance_km: float
    estimated_time_minutes: int
    route_steps: List[RouteStep]
    traffic_level: str = Field(..., description="Traffic level: low, moderate, high")
    estimated_arrival: datetime

# ==================== SIREN CONTROL ====================

class SirenToggleRequest(BaseModel):
    """Siren toggle request"""
    ambulance_id: str = Field(..., description="Ambulance ID")
    enable: bool = Field(..., description="Enable or disable siren")
    siren_type: str = Field(default="standard", description="Siren type")

class SirenToggleResponse(BaseModel):
    """Siren toggle response"""
    ambulance_id: str
    status: str = Field(..., description="Siren status: on, off")
    power_consumption_watts: float
    timestamp: datetime

# ==================== SMS & ALERTS ====================

class GuardianSMSRequest(BaseModel):
    """Guardian SMS alert request"""
    patient_id: str = Field(..., description="Patient ID")
    guardian_phone: str = Field(..., description="Guardian phone number")
    message_type: str = Field(..., description="Type of message")
    custom_message: Optional[str] = Field(None, description="Custom message")
    include_location: bool = Field(default=True, description="Include ambulance location")

class GuardianSMSResponse(BaseModel):
    """Guardian SMS alert response"""
    sms_id: str
    patient_id: str
    status: str = Field(..., description="Delivery status")
    sent_at: datetime
    message_preview: str

# ==================== INSURANCE ====================

class InsuranceAlertRequest(BaseModel):
    """Insurance alert request"""
    patient_id: str = Field(..., description="Patient ID")
    hospital_id: str = Field(..., description="Hospital ID")
    estimated_cost: float = Field(..., description="Estimated treatment cost")
    insurance_provider: Optional[str] = Field(None, description="Insurance provider")

class InsuranceAlertResponse(BaseModel):
    """Insurance alert response"""
    alert_id: str
    patient_id: str
    coverage_eligible: bool
    estimated_coverage: float
    patient_liability: float
    status: str = "pending"
    created_at: datetime

# ==================== PATIENT CARE PATHWAY ====================

class PathwayAction(BaseModel):
    """Single action in care pathway"""
    step_number: int = Field(..., description="Sequential step number")
    action: str = Field(..., description="Action description")
    urgency: str = Field(..., description="Urgency level: low, medium, high, critical")
    time_frame_minutes: int = Field(..., description="Time frame to complete action")
    responsible_party: str = Field(..., description="Who should perform this action")
    prerequisites: Optional[List[int]] = Field(None, description="Prerequisites (step numbers)")
    monitoring_parameters: Optional[List[str]] = Field(None, description="Parameters to monitor")

class PatientCarePathwayRequest(BaseModel):
    """Patient care pathway generation request"""
    patient_id: str = Field(..., description="Patient ID")
    vitals: PatientVitals = Field(..., description="Current patient vitals")
    symptoms: PatientSymptoms = Field(..., description="Patient symptoms")
    medical_files: Optional[List[str]] = Field(None, description="File paths for RAG analysis")
    include_offline_guidelines: bool = Field(default=True, description="Include offline medical guidelines")

class PatientCarePathway(BaseModel):
    """Generated patient care pathway"""
    pathway_id: str
    patient_id: str
    generated_at: datetime
    updated_at: datetime
    overall_confidence: float = Field(..., ge=0, le=1, description="Overall pathway confidence")
    severity_assessment: str = Field(..., description="Severity: stable, warning, critical")
    actions: List[PathwayAction] = Field(..., description="Ordered list of actions")
    clinical_summary: str = Field(..., description="Clinical summary and rationale")
    rag_sources: List[str] = Field(default=[], description="Medical guideline sources used")
    next_review_minutes: int = Field(..., description="Minutes until next review")

class PathwayUpdateRequest(BaseModel):
    """Request to update pathway based on new vitals"""
    pathway_id: str = Field(..., description="Pathway ID to update")
    patient_id: str = Field(..., description="Patient ID")
    new_vitals: PatientVitals = Field(..., description="Updated vitals")
    new_symptoms: Optional[PatientSymptoms] = Field(None, description="Updated symptoms")

# ==================== AMBULANCE & FLEET ====================

class AmbulanceStatus(BaseModel):
    """Ambulance status"""
    ambulance_id: str
    status: AmbulanceStatus
    current_lat: float
    current_lon: float
    driver_id: str
    paramedics: List[str]
    current_patient_id: Optional[str] = None
    siren_on: bool
    battery_level: int = Field(..., ge=0, le=100, description="Battery percentage")
    last_update: datetime

class FleetPerformanceRequest(BaseModel):
    """Fleet performance analytics request"""
    start_date: datetime
    end_date: datetime
    group_by: str = Field(default="day", description="Group by: day, week, month")

class AmbulanceMetrics(BaseModel):
    """Individual ambulance metrics"""
    ambulance_id: str
    total_calls: int
    average_response_time_minutes: float
    average_travel_time_minutes: float
    successful_deliveries: int
    distance_traveled_km: float
    fuel_consumption_liters: float

class FleetPerformanceResponse(BaseModel):
    """Fleet performance response"""
    period: str
    total_ambulances: int
    total_calls: int
    average_response_time_minutes: float
    average_travel_time_minutes: float
    success_rate: float = Field(..., ge=0, le=100, description="Percentage")
    metrics_by_ambulance: List[AmbulanceMetrics]

# ==================== OFFLINE CACHE ====================

class CacheEntry(BaseModel):
    """Offline cache entry"""
    key: str
    value: Dict[str, Any]
    created_at: datetime
    expires_at: datetime
    is_synced: bool = False

class SyncRequest(BaseModel):
    """Data sync request"""
    device_id: str
    last_sync_time: datetime
    cached_entries: List[CacheEntry]

class SyncResponse(BaseModel):
    """Data sync response"""
    synced_entries: int
    errors: List[str] = Field(default=[], description="Sync errors")
    server_updates: List[CacheEntry] = Field(default=[], description="Updates from server")
    
# RAG Models
class RAGQuery(BaseModel):
    """RAG query request"""
    query: str = Field(..., description="Clinical query or symptom")
    top_k: int = Field(5, description="Number of results to retrieve")
    filters: Optional[Dict[str, Any]] = Field(None, description="Optional metadata filters")

class RAGResult(BaseModel):
    """Single RAG retrieval result"""
    document: str = Field(..., description="Retrieved document excerpt")
    source: str = Field(..., description="Source of the document")
    category: str = Field(..., description="Document category")
    relevance_score: float = Field(..., ge=0, le=1, description="Relevance score 0-1")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")

class RAGResponse(BaseModel):
    """RAG query response"""
    query: str
    results: List[RAGResult]
    total_results: int
    processing_time_ms: float

class PathwayAction(BaseModel):
    """Single action step in care pathway"""
    step_number: int
    action: str
    urgency: str = Field(..., pattern="^(high|medium|low)$")

    time_frame_minutes: int
    responsible_party: str
    prerequisites: List[int] = []
    monitoring_parameters: List[str] = []

class PatientCarePathway(BaseModel):
    """Complete patient care pathway from LLM"""
    pathway_id: str
    patient_id: str
    severity_assessment: str = Field(..., pattern="^(STABLE|WARNING|CRITICAL)$")

    actions: List[PathwayAction]
    overall_confidence: float = Field(..., ge=0, le=1)
    clinical_summary: str
    rag_sources: List[str]
    warnings: List[str] = []
    recommendations: List[str] = []
    next_review_minutes: int
    generated_at: str
    updated_at: str

class PatientCarePathwayRequest(BaseModel):
    """Request to generate care pathway"""
    patient_id: str
    vitals: Dict[str, Any]
    symptoms: List[str]
    medical_history: Optional[List[str]] = None
    age: int
    weight_kg: Optional[float] = None

