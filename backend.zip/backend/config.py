# backend/config.py
"""
Configuration and environment variables for the Smart Ambulance System
"""

from pydantic_settings import BaseSettings
from typing import Optional
import os

class Settings(BaseSettings):
    """
    Application settings loaded from environment variables
    """
    
    # API Configuration
    APP_NAME: str = "Smart Ambulance & Healthcare Management System"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # Server Configuration
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    RELOAD: bool = True
    
    # Database Configuration
    # MongoDB
    MONGODB_URL: str = "mongodb://localhost:27017"
    MONGODB_DB_NAME: str = "ambulance_system"
    
    # PostgreSQL (Alternative)
    POSTGRES_URL: str = "postgresql://user:password@localhost:5432/ambulance_system"
    
    # Vector Database Configuration
    VECTOR_DB_TYPE: str = "milvus"  # Options: milvus, pinecone, weaviate
    MILVUS_HOST: str = "localhost"
    MILVUS_PORT: int = 19530
    PINECONE_API_KEY: Optional[str] = None
    PINECONE_ENVIRONMENT: Optional[str] = None
    WEAVIATE_URL: Optional[str] = None
    
    # JWT Configuration
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # LLM Configuration
    LLM_PROVIDER: str = "openai"  # Options: openai, cohere, huggingface
    OPENAI_API_KEY: Optional[str] = None
    COHERE_API_KEY: Optional[str] = None
    HUGGINGFACE_API_KEY: Optional[str] = None
    
    # IoT Configuration
    MQTT_BROKER: str = "localhost"
    MQTT_PORT: int = 1883
    MQTT_USERNAME: Optional[str] = None
    MQTT_PASSWORD: Optional[str] = None
    
    # SMS Configuration (Twilio)
    TWILIO_ACCOUNT_SID: Optional[str] = None
    TWILIO_AUTH_TOKEN: Optional[str] = None
    TWILIO_PHONE_NUMBER: Optional[str] = None
    
    # Google Maps API
    GOOGLE_MAPS_API_KEY: Optional[str] = None
    
    # Caching Configuration
    CACHE_TTL_MINUTES: int = 60
    OFFLINE_CACHE_DIR: str = "./cache"
    
    # Medical AI Configuration
    ECG_ANOMALY_THRESHOLD: float = 0.7
    CONFIDENCE_THRESHOLD: float = 0.6
    RAG_CHUNK_SIZE: int = 512
    RAG_CHUNK_OVERLAP: int = 50
    
    class Config:
        env_file = ".env"
        case_sensitive = True

        # LLM / RAG settings
    OPENAI_MODEL: str = "gpt-3.5-turbo"
    LLM_TEMPERATURE: float = 0.3
    LLM_MAX_TOKENS: int = 2000

    RAG_TOP_K: int = 5
    FAISS_INDEX_PATH: str = "data/medical_guidelines.faiss"

    ENABLE_RAG_CACHE: bool = True
    CACHE_TTL_SECONDS: int = 3600

# Load settings
settings = Settings()

# Create directories if they don't exist
os.makedirs(settings.OFFLINE_CACHE_DIR, exist_ok=True)
# RAG Configuration
RAG_CHUNK_SIZE = int(os.getenv("RAG_CHUNK_SIZE", "1000"))
RAG_CHUNK_OVERLAP = int(os.getenv("RAG_CHUNK_OVERLAP", "200"))
RAG_TOP_K = int(os.getenv("RAG_TOP_K", "5"))

# Vector Store Configuration
VECTOR_DB_TYPE = os.getenv("VECTOR_DB_TYPE", "faiss")
FAISS_INDEX_PATH = os.getenv("FAISS_INDEX_PATH", "data/medical_guidelines.faiss")

# LLM Configuration
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.3"))
LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "2000"))

# Medical Guidelines Directory
MEDICAL_GUIDELINES_DIR = os.getenv("MEDICAL_GUIDELINES_DIR", "data/guidelines")

# Caching
ENABLE_RAG_CACHE = os.getenv("ENABLE_RAG_CACHE", "true").lower() == "true"
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "3600"))

# Create necessary directories
os.makedirs(MEDICAL_GUIDELINES_DIR, exist_ok=True)
os.makedirs(os.path.dirname(FAISS_INDEX_PATH), exist_ok=True)

