"""Medical documents & guidelines database"""

MEDICAL_GUIDELINES_DATABASE = {
    "hypertension": {
        "conditions": ["high blood pressure", "hypertension", "elevated BP"],
        "severity_thresholds": {
            "normal": {"sys": 120, "dia": 80},
            "elevated": {"sys": 129, "dia": 80},
            "stage1": {"sys": 139, "dia": 89},
            "stage2": {"sys": 160, "dia": 100},
            "crisis": {"sys": 180, "dia": 120}
        }
    },
    "acs": {
        "conditions": ["chest pain", "acute coronary", "MI", "infarction", "angina"],
        "red_flags": ["ST elevation", "troponin elevation", "ECG changes"],
        "priority_actions": [
            "12-lead ECG within 10 minutes",
            "IV access (18G or larger)",
            "Aspirin 325-500mg",
            "Cardiac monitoring"
        ]
    },
    "sepsis": {
        "conditions": ["sepsis", "septic shock", "infection"],
        "criteria": {
            "body_temp": {"low": 36, "high": 38},
            "heart_rate": 90,
            "respiratory_rate": 20,
            "wbc_low": 4000,
            "wbc_high": 12000
        }
    },
    "stroke": {
        "conditions": ["stroke", "CVA", "TIA", "cerebral infarction"],
        "time_windows": {
            "thrombolysis": 270,  # 4.5 hours in minutes
            "thrombectomy": 1440  # 24 hours in minutes
        },
        "key_actions": ["STAT CT/MRI", "12-lead ECG", "Blood glucose", "Labs"]
    }
}

MEDICATION_DATABASE = {
    "aspirin": {"dose": "325-500mg", "route": "PO", "frequency": "single"},
    "nitroglycerin": {"dose": "0.3-0.6mg", "route": "sublingual", "frequency": "q5min x3"},
    "morphine": {"dose": "2-4mg IV", "route": "IV", "frequency": "q5-15min"},
}

SEVERITY_INDICATORS = {
    "critical": ["SBP>180", "HR>130", "SpO2<90", "RR>30", "GCS<8"],
    "warning": ["SBP>160", "HR>110", "SpO2<94", "RR>24", "GCS<12"],
    "stable": ["SBP 90-160", "HR 60-100", "SpO2>95", "RR 12-20", "GCS>12"]
}
