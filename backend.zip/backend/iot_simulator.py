# backend/simulation/iot_simulator.py
"""
IoT Device Simulator for vitals and GPS data
Simulates realistic patient vital signs and ambulance GPS data
"""

import asyncio
import json
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import math
import logging

logger = logging.getLogger(__name__)

class VitalsSimulator:
    """
    Simulates realistic patient vital signs
    """
    
    # Normal ranges
    NORMAL_RANGES = {
        "heart_rate": (60, 100),
        "blood_pressure_sys": (90, 120),
        "blood_pressure_dia": (60, 80),
        "oxygen_saturation": (95, 100),
        "respiratory_rate": (12, 20),
        "body_temperature": (36.5, 37.5),
    }
    
    # Abnormal patterns
    CONDITIONS = {
        "tachycardia": {"heart_rate": (120, 160)},
        "hypertension": {"blood_pressure_sys": (160, 200), "blood_pressure_dia": (100, 120)},
        "hypoxia": {"oxygen_saturation": (85, 94)},
        "fever": {"body_temperature": (38.5, 40.0)},
        "bradycardia": {"heart_rate": (40, 60)},
        "shock": {"heart_rate": (130, 180), "blood_pressure_sys": (60, 90)},
        "normal": NORMAL_RANGES
    }
    
    def __init__(self, condition: str = "normal"):
        """
        Initialize vitals simulator
        
        Args:
            condition: Patient condition to simulate
        """
        self.condition = condition
        self.current_state = {}
        self._initialize_state()
    
    def _initialize_state(self):
        """Initialize starting vital values"""
        ranges = self.CONDITIONS.get(self.condition, self.NORMAL_RANGES)
        
        self.current_state = {
            "heart_rate": random.uniform(*ranges.get("heart_rate", (60, 100))),
            "blood_pressure_sys": random.uniform(*ranges.get("blood_pressure_sys", (90, 120))),
            "blood_pressure_dia": random.uniform(*ranges.get("blood_pressure_dia", (60, 80))),
            "oxygen_saturation": random.uniform(*ranges.get("oxygen_saturation", (95, 100))),
            "respiratory_rate": random.uniform(*ranges.get("respiratory_rate", (12, 20))),
            "body_temperature": random.uniform(*ranges.get("body_temperature", (36.5, 37.5))),
        }
    
    def get_next_reading(self, trend: str = "stable") -> Dict[str, float]:
        """
        Generate next vital signs reading with realistic variations
        
        Args:
            trend: "improving", "worsening", or "stable"
            
        Returns:
            Dictionary of vital signs
        """
        # Apply trend
        if trend == "worsening":
            variation = 1.02  # Worsen by 2%
        elif trend == "improving":
            variation = 0.98  # Improve by 2%
        else:
            variation = 1.0 + random.uniform(-0.01, 0.01)  # ±1% variation
        
        # Update each vital with random walk + trend
        for key in self.current_state:
            base_value = self.current_state[key] * variation
            noise = random.gauss(0, self.current_state[key] * 0.02)
            self.current_state[key] = max(0, base_value + noise)
        
        # Generate ECG-like signal
        ecg_reading = self._generate_ecg()
        
        return {
            **self.current_state,
            "ecg_reading": ecg_reading,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    def _generate_ecg(self, duration_seconds: float = 1.0, sampling_rate: int = 256) -> List[float]:
        """
        Generate realistic ECG waveform
        
        Args:
            duration_seconds: Duration of ECG signal
            sampling_rate: Sampling rate in Hz
            
        Returns:
            List of ECG values in mV
        """
        samples = int(duration_seconds * sampling_rate)
        ecg = []
        
        # Generate multiple heartbeats
        hr = self.current_state.get("heart_rate", 70)
        beat_duration = 60 / hr  # Duration of one heartbeat
        
        for i in range(samples):
            t = i / sampling_rate
            beat_phase = (t % beat_duration) / beat_duration  # 0 to 1
            
            # Simplified ECG waveform (PQRST complex)
            if beat_phase < 0.2:  # P wave
                value = 0.1 * math.sin(beat_phase * math.pi / 0.2)
            elif beat_phase < 0.4:  # PQ segment
                value = 0
            elif beat_phase < 0.6:  # QRS complex (dominant)
                qrs_phase = (beat_phase - 0.4) / 0.2
                value = math.sin(qrs_phase * math.pi) * 1.5
            elif beat_phase < 0.8:  # ST segment
                value = 0
            else:  # T wave
                t_phase = (beat_phase - 0.8) / 0.2
                value = 0.3 * math.sin(t_phase * math.pi)
            
            # Add noise
            noise = random.gauss(0, 0.05)
            ecg.append(value + noise)
        
        return ecg


class GPSSimulator:
    """
    Simulates ambulance GPS movement
    """
    
    def __init__(self, start_lat: float, start_lon: float):
        """
        Initialize GPS simulator
        
        Args:
            start_lat: Starting latitude
            start_lon: Starting longitude
        """
        self.current_lat = start_lat
        self.current_lon = start_lon
        self.destination_lat = start_lat + random.uniform(-0.05, 0.05)
        self.destination_lon = start_lon + random.uniform(-0.05, 0.05)
        self.speed_kmh = random.uniform(40, 80)
    
    def get_next_position(self, elapsed_seconds: float = 1.0) -> Dict[str, float]:
        """
        Generate next GPS position
        
        Args:
            elapsed_seconds: Seconds elapsed since last position
            
        Returns:
            Dictionary with latitude, longitude, and accuracy
        """
        # Calculate distance to travel
        distance_km = (self.speed_kmh * elapsed_seconds) / 3600
        
        # Calculate direction to destination
        lat_diff = self.destination_lat - self.current_lat
        lon_diff = self.destination_lon - self.current_lon
        distance_to_dest = math.sqrt(lat_diff**2 + lon_diff**2)
        
        if distance_to_dest > 0.001:  # ~100 meters
            # Move towards destination
            direction_lat = lat_diff / distance_to_dest
            direction_lon = lon_diff / distance_to_dest
            
            # Update position
            self.current_lat += direction_lat * (distance_km / 111.0)  # 1° ≈ 111 km
            self.current_lon += direction_lon * (distance_km / 111.0)
        else:
            # Generate new destination
            self.destination_lat = self.current_lat + random.uniform(-0.05, 0.05)
            self.destination_lon = self.current_lon + random.uniform(-0.05, 0.05)
        
        # Add GPS noise (accuracy)
        accuracy = random.uniform(5, 20)  # 5-20 meters
        gps_lat = self.current_lat + random.gauss(0, accuracy / 111000)
        gps_lon = self.current_lon + random.gauss(0, accuracy / 111000)
        
        return {
            "latitude": gps_lat,
            "longitude": gps_lon,
            "accuracy_meters": accuracy,
            "speed_kmh": self.speed_kmh,
            "heading_degrees": self._calculate_heading(),
            "timestamp": datetime.utcnow().isoformat()
        }
    
    def _calculate_heading(self) -> float:
        """Calculate heading to destination"""
        lat_diff = self.destination_lat - self.current_lat
        lon_diff = self.destination_lon - self.current_lon
        heading = math.atan2(lon_diff, lat_diff) * 180 / math.pi
        return (heading + 360) % 360


class AmbulanceSimulator:
    """
    Simulates complete ambulance with patient
    """
    
    def __init__(
        self,
        ambulance_id: str,
        patient_id: str,
        start_lat: float = 28.6139,  # New Delhi
        start_lon: float = 77.2090,
        patient_condition: str = "stable"
    ):
        """
        Initialize ambulance simulator
        
        Args:
            ambulance_id: Ambulance identifier
            patient_id: Patient identifier
            start_lat: Starting latitude
            start_lon: Starting longitude
            patient_condition: Patient condition to simulate
        """
        self.ambulance_id = ambulance_id
        self.patient_id = patient_id
        self.vitals_sim = VitalsSimulator(condition=patient_condition)
        self.gps_sim = GPSSimulator(start_lat, start_lon)
        self.siren_on = False
        self.simulation_time = 0
    
    async def stream_vitals(
        self,
        duration_seconds: int = 60,
        interval_seconds: float = 1.0,
        callback=None
    ):
        """
        Stream vital signs data
        
        Args:
            duration_seconds: Total simulation duration
            interval_seconds: Update interval
            callback: Callback function for each reading
        """
        start_time = datetime.utcnow()
        
        while self.simulation_time < duration_seconds:
            reading = {
                "ambulance_id": self.ambulance_id,
                "patient_id": self.patient_id,
                "gps": self.gps_sim.get_next_position(interval_seconds),
                "vitals": self.vitals_sim.get_next_reading(),
                "siren_on": self.siren_on,
                "simulation_time": self.simulation_time
            }
            
            if callback:
                await callback(reading)
            
            self.simulation_time += interval_seconds
            await asyncio.sleep(interval_seconds)
    
    def set_siren(self, enabled: bool):
        """Toggle siren"""
        self.siren_on = enabled


class DataGenerator:
    """
    Generates realistic test data
    """
    
    @staticmethod
    def generate_sample_patient_data() -> Dict:
        """Generate sample patient data"""
        return {
            "id": f"PAT_{random.randint(1000, 9999)}",
            "name": random.choice([
                "Rajesh Kumar", "Priya Singh", "Amit Patel",
                "Neha Sharma", "Vikram Verma", "Anjali Gupta"
            ]),
            "age": random.randint(20, 80),
            "gender": random.choice(["M", "F"]),
            "blood_group": random.choice(["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"]),
            "phone": f"+91{random.randint(7000000000, 9999999999)}",
            "emergency_contact": f"+91{random.randint(7000000000, 9999999999)}",
            "medical_history": random.sample([
                "Hypertension", "Diabetes", "Asthma", "COPD",
                "Heart Disease", "Arthritis", "Thyroid"
            ], k=random.randint(0, 3)),
            "current_medications": random.sample([
                "Metformin", "Lisinopril", "Atorvastatin",
                "Aspirin", "Albuterol", "Metoprolol"
            ], k=random.randint(0, 4)),
            "allergies": random.sample([
                "Penicillin", "Sulfa", "NSAIDs", "Latex"
            ], k=random.randint(0, 2))
        }
    
    @staticmethod
    def generate_sample_hospitals() -> List[Dict]:
        """Generate sample hospital data"""
        cities = [
            ("Delhi", 28.6139, 77.2090),
            ("Mumbai", 19.0760, 72.8777),
            ("Bangalore", 12.9716, 77.5946),
        ]
        
        hospitals = []
        for city, lat, lon in cities:
            for i in range(3):
                hospitals.append({
                    "id": f"HSP_{city.upper()}_{i+1}",
                    "name": f"{city} Medical Center {i+1}",
                    "latitude": lat + random.uniform(-0.01, 0.01),
                    "longitude": lon + random.uniform(-0.01, 0.01),
                    "total_beds": random.randint(100, 500),
                    "icu_beds": random.randint(20, 100),
                    "general_beds": random.randint(50, 300),
                    "emergency_beds": random.randint(10, 50),
                    "phone": f"+91{random.randint(1100000000, 1199999999)}",
                    "specializations": random.sample([
                        "Cardiology", "Neurology", "Orthopedics",
                        "Emergency", "ICU", "Trauma"
                    ], k=random.randint(2, 5))
                })
        
        return hospitals


# Example usage functions
async def demo_ambulance_simulation():
    """Demonstrate ambulance simulation"""
    ambulance = AmbulanceSimulator("AMB001", "PAT001")
    
    async def on_vitals_update(reading):
        logger.info(f"Vitals Update: HR={reading['vitals']['heart_rate']:.0f} "
                   f"BP={reading['vitals']['blood_pressure_sys']:.0f}/{reading['vitals']['blood_pressure_dia']:.0f} "
                   f"SpO2={reading['vitals']['oxygen_saturation']:.1f}%")
    
    await ambulance.stream_vitals(duration_seconds=10, callback=on_vitals_update)


if __name__ == "__main__":
    # Test data generation
    patient = DataGenerator.generate_sample_patient_data()
    hospitals = DataGenerator.generate_sample_hospitals()
    
    print("Sample Patient:")
    print(json.dumps(patient, indent=2))
    print("\nSample Hospitals:")
    print(json.dumps(hospitals[:2], indent=2))
