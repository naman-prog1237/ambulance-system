import { useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import {
  LayoutDashboard,
  MessageCircle,
  Users,
  Hospital,
  Ambulance,
  Settings,
  Menu,
  X,
} from 'lucide-react';

export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(true);
  const location = useLocation();
  const userRole = useStore((state) => state.userRole);

  const menuItems = [
    { name: 'Dashboard', icon: LayoutDashboard, href: '/dashboard' },
    { name: 'Chat (RAG+LLM)', icon: MessageCircle, href: '/chat' },
    { name: 'Patients', icon: Users, href: '/patients' },
    { name: 'Hospitals', icon: Hospital, href: '/hospitals' },
    ...(userRole !== 'patient' ? [{ name: 'Ambulances', icon: Ambulance, href: '/ambulances' }] : []),
    { name: 'Settings', icon: Settings, href: '/settings' },
  ];

  const isActive = (href) => location.pathname === href;

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed top-4 left-4 z-50 p-2 bg-blue-600 text-white rounded-lg"
      >
        {isOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      <aside
        className={`${
          isOpen ? 'w-64' : 'w-0'
        } bg-gray-900 text-white transition-all duration-300 flex flex-col overflow-hidden md:w-64`}
      >
        <div className="p-6 border-b border-gray-700">
          <h2 className="text-2xl font-bold">🚑 Ambulance</h2>
          <p className="text-xs text-gray-400 mt-1">Healthcare Management</p>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                to={item.href}
                className={`flex items-center gap-3 px-4 py-2 rounded-lg transition ${
                  isActive(item.href)
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-800'
                }`}
              >
                <Icon size={20} />
                <span className="hidden md:inline">{item.name}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-gray-700 text-xs text-gray-400">
          <p>v1.0.0</p>
          <p>© 2024 Smart Ambulance</p>
        </div>
      </aside>
    </>
  );
}
