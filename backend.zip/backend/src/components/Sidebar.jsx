import { useLocation, useNavigate } from 'react-router-dom';
import {
  Activity,
  Users,
  MapPin,
  AlertCircle,
  DollarSign,
  Volume2,
  LogOut,
  Home,
  Bed,
  Building2,
  Brain,
} from 'lucide-react';

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { label: 'Dashboard', icon: Home, path: '/dashboard' },
    { label: 'Vitals Monitoring', icon: Activity, path: '/vitals' },
    { label: 'Bed Availability', icon: Bed, path: '/beds' },
    { label: 'Hospitals', icon: Building2, path: '/hospitals' },
    { label: 'Route Optimization', icon: MapPin, path: '/route' },
    { label: 'Alerts', icon: AlertCircle, path: '/alerts' },
    { label: 'Siren Control', icon: Volume2, path: '/siren' },
    { label: 'Insurance', icon: DollarSign, path: '/insurance' },
    { label: 'Clinical Decision Support', icon: Brain, path: '/clinical-decision' },
  ];

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/auth');
  };

  return (
    <div className="w-64 bg-gradient-to-b from-blue-900 to-blue-800 text-white h-screen overflow-y-auto">
      {/* Logo */}
      <div className="p-6 border-b border-blue-700">
        <div className="flex items-center gap-3">
          <div className="bg-blue-100 p-2 rounded-lg">
            <Users className="w-6 h-6 text-blue-900" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Smart Ambulance</h1>
            <p className="text-xs text-blue-200">Management System</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                isActive
                  ? 'bg-blue-100 text-blue-900 font-semibold'
                  : 'text-blue-100 hover:bg-blue-700'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Logout Button */}
      <div className="absolute bottom-0 w-full p-4 border-t border-blue-700">
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg bg-red-600 hover:bg-red-700 transition text-white font-medium"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
}
