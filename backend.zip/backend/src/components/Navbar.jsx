import React from 'react';
import { Bell, User, Menu } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function Navbar({ onMenuClick }) {
  const { user } = useAuth();

  return (
    <header className="glass sticky top-0 z-30 px-6 py-4 border-b border-gray-200">
      <div className="flex items-center justify-between">
        {/* Mobile menu button */}
        <button
          onClick={onMenuClick}
          className="p-2 rounded-lg text-gray-700 hover:bg-gray-100 lg:hidden neumorphic"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Title */}
        <h2 className="text-xl font-semibold text-gray-900 hidden md:block">
          Smart Ambulance Control
        </h2>

        {/* Right side */}
        <div className="flex items-center space-x-4">
          <button className="p-2 text-gray-700 hover:bg-gray-100 rounded-xl transition-all neumorphic relative">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
          </button>

          {user && (
            <div className="flex items-center space-x-3 p-2 rounded-xl bg-gradient-to-r from-primary-50 to-blue-50">
              <div className="w-8 h-8 bg-gradient-to-r from-primary-500 to-blue-600 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-900 hidden md:block">
                {user.name}
              </span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
