import React from 'react';

export default function Card({
  children,
  className = '',
  title,
  icon,              // accept icon
  ...props
}) {
  return (
    <div
      className={`bg-white/5 border border-white/10 rounded-2xl p-4 shadow-sm ${className}`}
      {...props}
    >
      <div className="flex items-center justify-between mb-2">
        {title && (
          <h3 className="text-sm font-medium text-slate-200">
            {title}
          </h3>
        )}
        {icon && (
          <div className="text-slate-400">
            {icon}
          </div>
        )}
      </div>

      <div>
        {children}
      </div>
    </div>
  );
}
