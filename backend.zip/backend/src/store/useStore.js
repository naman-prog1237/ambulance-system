import { create } from 'zustand';

export const useStore = create((set) => ({
  // User state
  user: null,
  isAuthenticated: false,
  userRole: null,

  // UI state
  loading: false,
  error: null,
  successMessage: null,

  // Chat state
  chatMessages: [],
  chatHistory: [],

  // Patient data
  patients: [],
  currentPatient: null,

  // Hospital data
  hospitals: [],
  selectedHospital: null,

  // Ambulance data
  ambulances: [],
  selectedAmbulance: null,

  // Actions
  setUser: (user) => set({ user, isAuthenticated: !!user, userRole: user?.role }),
  logout: () => set({ user: null, isAuthenticated: false, userRole: null }),

  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
  setSuccess: (message) => set({ successMessage: message }),
  clearMessages: () => set({ error: null, successMessage: null }),

  addChatMessage: (message) => set((state) => ({
    chatMessages: [...state.chatMessages, message],
  })),
  clearChatMessages: () => set({ chatMessages: [] }),
  setChatHistory: (history) => set({ chatHistory: history }),

  setPatients: (patients) => set({ patients }),
  setCurrentPatient: (patient) => set({ currentPatient: patient }),

  setHospitals: (hospitals) => set({ hospitals }),
  setSelectedHospital: (hospital) => set({ selectedHospital: hospital }),

  setAmbulances: (ambulances) => set({ ambulances }),
  setSelectedAmbulance: (ambulance) => set({ selectedAmbulance: ambulance }),
}));
