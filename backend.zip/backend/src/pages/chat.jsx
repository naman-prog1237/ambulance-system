import { useState, useRef, useEffect } from 'react';
import { useStore } from '../store/useStore';
import Navbar from '../components/common/Navbar';
import Sidebar from '../components/common/Sidebar';
import apiClient from '../services/api';
import { endpoints } from '../services/endpoints';
import { Send, MessageCircle, Loader } from 'lucide-react';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

export default function Chat() {
  const chatMessages = useStore((state) => state.chatMessages);
  const addChatMessage = useStore((state) => state.addChatMessage);
  const clearChatMessages = useStore((state) => state.clearChatMessages);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState('');
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, streamingMessage]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    addChatMessage(userMessage);
    setInput('');
    setLoading(true);
    setStreamingMessage('');

    try {
      const response = await apiClient.post(endpoints.rag.query, {
        query: input,
        top_k: 5,
      });

      const ragResults = response.data.results;
      let formattedResponse = `📚 **Medical Guidelines (${ragResults.length} results):**\n\n`;

      ragResults.forEach((result, index) => {
        formattedResponse += `**${index + 1}. ${result.source}**\n`;
        formattedResponse += `${result.document.substring(0, 150)}...\n\n`;
      });

      await streamMessage(formattedResponse);

      const aiMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: formattedResponse,
        timestamp: new Date(),
      };

      addChatMessage(aiMessage);
      setStreamingMessage('');
    } catch (error) {
      toast.error('Failed to get response');
      setStreamingMessage('');
    } finally {
      setLoading(false);
    }
  };

  const streamMessage = (message) => {
    return new Promise((resolve) => {
      let index = 0;
      const interval = setInterval(() => {
        if (index < message.length) {
          setStreamingMessage((prev) => prev + message[index]);
          index++;
        } else {
          clearInterval(interval);
          resolve();
        }
      }, 10);
    });
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        <main className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {chatMessages.length === 0 && !streamingMessage && (
              <div className="flex flex-col items-center justify-center h-full">
                <MessageCircle size={64} className="text-gray-300 mb-4" />
                <h2 className="text-2xl font-bold text-gray-800">Ask Medical Questions</h2>
                <p className="text-gray-600 mt-2">Get instant answers powered by Medical Guidelines</p>
              </div>
            )}

            {chatMessages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-md px-4 py-3 rounded-lg ${
                    msg.role === 'user'
                      ? 'bg-blue-600 text-white rounded-br-none'
                      : 'bg-gray-200 text-gray-900 rounded-bl-none'
                  }`}
                >
                  <p className="text-sm">{msg.content}</p>
                  <p className={`text-xs mt-1 ${msg.role === 'user' ? 'text-blue-100' : 'text-gray-500'}`}>
                    {format(msg.timestamp, 'HH:mm')}
                  </p>
                </div>
              </div>
            ))}

            {streamingMessage && (
              <div className="flex justify-start">
                <div className="max-w-md px-4 py-3 rounded-lg bg-gray-200 text-gray-900 rounded-bl-none">
                  <p className="text-sm whitespace-pre-wrap">{streamingMessage}</p>
                  <div className="inline-block ml-1 h-4 w-0.5 bg-gray-600 animate-pulse"></div>
                </div>
              </div>
            )}

            {loading && !streamingMessage && (
              <div className="flex justify-center">
                <div className="flex items-center gap-2 text-gray-600">
                  <Loader className="animate-spin" size={20} />
                  <span>Retrieving medical guidelines...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          <div className="bg-white border-t p-4">
            <form onSubmit={handleSendMessage} className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask a medical question..."
                className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={loading}
              />
              <button
                type="submit"
                disabled={loading || !input.trim()}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-6 py-2 rounded-lg transition flex items-center gap-2"
              >
                {loading ? <Loader className="animate-spin" size={18} /> : <Send size={18} />}
                Send
              </button>
              <button
                type="button"
                onClick={clearChatMessages}
                className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-lg"
              >
                Clear
              </button>
            </form>
          </div>
        </main>
      </div>
    </div>
  );
}
