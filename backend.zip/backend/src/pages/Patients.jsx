import { useEffect } from 'react';
import { useStore } from '../store/useStore';
import Navbar from '../components/common/Navbar';
import Sidebar from '../components/common/Sidebar';

export default function Patients() {
  const user = useStore((state) => state.user);

  useEffect(() => {
    // Placeholder for fetching patients data if needed
  }, []);

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        <main className="flex-1 p-8 overflow-y-auto">
          <h1 className="text-3xl font-bold mb-4">Patients Page</h1>
          <div className="bg-white rounded-lg shadow p-6">
            <p className="text-gray-700">This is the Patients management page.</p>
            {/* Future: List patients, add forms, etc. */}
          </div>
        </main>
      </div>
    </div>
  );
}
