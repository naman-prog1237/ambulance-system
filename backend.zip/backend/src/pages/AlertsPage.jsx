import React, { useState } from 'react';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';
import { AlertTriangle, Phone } from 'lucide-react';
import { alertsAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function AlertsPage() {
  const [formData, setFormData] = useState({
    patient_id: '',
    guardian_phone: '',
    message_type: 'critical',
    custom_message: '',
    include_location: true,
  });
  const [loading, setLoading] = useState(false);
  const [sms, setSms] = useState(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.patient_id || !formData.guardian_phone) {
      toast.error('Patient ID and guardian phone are required');
      return;
    }

    setLoading(true);
    try {
      const res = await alertsAPI.sendGuardianSMS({
        patient_id: formData.patient_id,
        guardian_phone: formData.guardian_phone,
        message_type: formData.message_type,
        custom_message: formData.custom_message || null,
        include_location: formData.include_location,
      });
      setSms(res.data);
      toast.success('Alert sent to guardian');
    } catch {
      toast.error('Failed to send alert');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <AlertTriangle className="w-8 h-8 text-orange-500" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Guardian Alerts</h1>
          <p className="text-gray-600">Instant SMS alerts to patient guardians.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form */}
        <Card className="lg:col-span-1">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Patient ID"
              name="patient_id"
              value={formData.patient_id}
              onChange={handleChange}
              placeholder="PAT-001"
            />
            <Input
              label="Guardian Phone"
              name="guardian_phone"
              value={formData.guardian_phone}
              onChange={handleChange}
              placeholder="+91XXXXXXXXXX"
            />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Message Type
              </label>
              <select
                name="message_type"
                value={formData.message_type}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 shadow-neumorphic focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="info">Info</option>
                <option value="critical">Critical</option>
                <option value="update">Update</option>
              </select>
            </div>
            <Input
              label="Custom Message (optional)"
              name="custom_message"
              value={formData.custom_message}
              onChange={handleChange}
              placeholder="Any additional details for guardian..."
            />
            <label className="inline-flex items-center space-x-2 text-sm text-gray-700">
              <input
                type="checkbox"
                name="include_location"
                checked={formData.include_location}
                onChange={handleChange}
                className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
              />
              <span>Include ambulance location link</span>
            </label>
            <Button type="submit" loading={loading} className="w-full">
              <Phone className="w-4 h-4 mr-2" />
              Send SMS Alert
            </Button>
          </form>
        </Card>

        {/* Result */}
        <Card className="lg:col-span-1">
          {sms ? (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">SMS Delivery</h2>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">SMS ID</p>
                  <p className="font-semibold">{sms.sms_id}</p>
                </div>
                <div>
                  <p className="text-gray-500">Patient</p>
                  <p className="font-semibold">{sms.patient_id}</p>
                </div>
                <div>
                  <p className="text-gray-500">Status</p>
                  <p className="font-semibold">{sms.status}</p>
                </div>
                <div>
                  <p className="text-gray-500">Sent At</p>
                  <p className="font-semibold">
                    {new Date(sms.sent_at).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-200">
                <p className="text-sm font-semibold text-gray-900 mb-2">Message Preview</p>
                <p className="text-sm text-gray-700 whitespace-pre-wrap">
                  {sms.message_preview}
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-400">
              Send an alert to see delivery details.
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
