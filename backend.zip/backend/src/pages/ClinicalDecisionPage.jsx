import React, { useState, useEffect } from 'react';
import {
  Brain,
  Send,
  Loader,
  AlertCircle,
  CheckCircle,
  Zap,
  Heart,
  Settings,
  Download,
  Copy,
} from 'lucide-react';
import { ragAPI, pathwayAPI, llmAPI } from '../services/api';
import Button from '../components/Button';
import Card from '../components/Card';
import toast from 'react-hot-toast';

export default function ClinicalDecisionPage() {
  const [activeTab, setActiveTab] = useState('rag'); // rag | pathway | analysis

  // RAG Query State
  const [ragQuery, setRagQuery] = useState('');
  const [ragResults, setRagResults] = useState(null);
  const [ragLoading, setRagLoading] = useState(false);
  const [ragHistory, setRagHistory] = useState([]);

  // Pathway Generation State
  const [pathwayData, setPathwayData] = useState({
    heart_rate: '',
    blood_pressure: '',
    temperature: '',
    oxygen_saturation: '',
    respiratory_rate: '',
    symptoms: '',
    medical_history: '',
    allergies: '',
    current_medications: '',
    patient_age: '',
    patient_gender: 'M',
    emergency_level: 'medium',
  });
  const [pathway, setPathway] = useState(null);
  const [pathwayLoading, setPathwayLoading] = useState(false);

  // Clinical Analysis State
  const [analysisData, setAnalysisData] = useState({
    chief_complaint: '',
    symptoms: '',
    heart_rate: '',
    blood_pressure: '',
    temperature: '',
    oxygen_saturation: '',
    respiratory_rate: '',
    medical_history: '',
    allergies: '',
    current_medications: '',
    patient_age: '',
    patient_gender: 'M',
  });
  const [analysis, setAnalysis] = useState(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);

  // ==================== RAG TAB FUNCTIONS ====================
  const handleRagQuery = async () => {
    if (!ragQuery.trim()) {
      toast.error('Please enter a medical query');
      return;
    }

    setRagLoading(true);
    try {
      const response = await ragAPI.query({
        query: ragQuery,
        context: '',
        top_k: 5,
      });

      setRagResults(response.data);
      setRagHistory([
        { query: ragQuery, timestamp: new Date(), result: response.data },
        ...ragHistory.slice(0, 9), // Keep last 10 queries
      ]);
      toast.success('Medical knowledge retrieved!');
    } catch (error) {
      toast.error('Failed to query medical knowledge base');
      console.error(error);
    } finally {
      setRagLoading(false);
    }
  };

  // ==================== PATHWAY TAB FUNCTIONS ====================
  const handlePathwayGenerate = async () => {
    // Validate required fields
    if (!pathwayData.heart_rate || !pathwayData.blood_pressure) {
      toast.error('Please enter heart rate and blood pressure');
      return;
    }

    setPathwayLoading(true);
    try {
      const response = await pathwayAPI.generateWithRag({
        ...pathwayData,
        heart_rate: parseInt(pathwayData.heart_rate),
        temperature: pathwayData.temperature ? parseFloat(pathwayData.temperature) : null,
        oxygen_saturation: pathwayData.oxygen_saturation
          ? parseFloat(pathwayData.oxygen_saturation)
          : null,
        respiratory_rate: pathwayData.respiratory_rate
          ? parseInt(pathwayData.respiratory_rate)
          : null,
        patient_age: pathwayData.patient_age ? parseInt(pathwayData.patient_age) : null,
        symptoms: pathwayData.symptoms ? pathwayData.symptoms.split(',').map((s) => s.trim()) : [],
        medical_history: pathwayData.medical_history
          ? pathwayData.medical_history.split(',').map((m) => m.trim())
          : [],
        allergies: pathwayData.allergies ? pathwayData.allergies.split(',').map((a) => a.trim()) : [],
        current_medications: pathwayData.current_medications
          ? pathwayData.current_medications.split(',').map((med) => med.trim())
          : [],
      });

      setPathway(response.data);
      toast.success('Clinical pathway generated with LLM + RAG!');
    } catch (error) {
      toast.error('Failed to generate clinical pathway');
      console.error(error);
    } finally {
      setPathwayLoading(false);
    }
  };

  // ==================== ANALYSIS TAB FUNCTIONS ====================
  const handleAnalyze = async () => {
    if (!analysisData.chief_complaint.trim()) {
      toast.error('Please enter chief complaint');
      return;
    }

    setAnalysisLoading(true);
    try {
      const response = await llmAPI.clinicalDecisionSupport({
        patient_id: 'temp-' + Date.now(),
        chief_complaint: analysisData.chief_complaint,
        ...analysisData,
        heart_rate: analysisData.heart_rate ? parseInt(analysisData.heart_rate) : null,
        temperature: analysisData.temperature ? parseFloat(analysisData.temperature) : null,
        oxygen_saturation: analysisData.oxygen_saturation
          ? parseFloat(analysisData.oxygen_saturation)
          : null,
        respiratory_rate: analysisData.respiratory_rate
          ? parseInt(analysisData.respiratory_rate)
          : null,
        patient_age: analysisData.patient_age ? parseInt(analysisData.patient_age) : null,
        patient_vitals: {
          heart_rate: analysisData.heart_rate ? parseInt(analysisData.heart_rate) : null,
          blood_pressure: analysisData.blood_pressure,
          temperature: analysisData.temperature ? parseFloat(analysisData.temperature) : null,
          oxygen_saturation: analysisData.oxygen_saturation
            ? parseFloat(analysisData.oxygen_saturation)
            : null,
          respiratory_rate: analysisData.respiratory_rate
            ? parseInt(analysisData.respiratory_rate)
            : null,
        },
        symptoms: analysisData.symptoms ? analysisData.symptoms.split(',').map((s) => s.trim()) : [],
        medical_history: analysisData.medical_history
          ? analysisData.medical_history.split(',').map((m) => m.trim())
          : [],
        allergies: analysisData.allergies
          ? analysisData.allergies.split(',').map((a) => a.trim())
          : [],
        current_medications: analysisData.current_medications
          ? analysisData.current_medications.split(',').map((med) => med.trim())
          : [],
      });

      setAnalysis(response.data);
      toast.success('Clinical analysis complete!');
    } catch (error) {
      toast.error('Failed to analyze clinical data');
      console.error(error);
    } finally {
      setAnalysisLoading(false);
    }
  };

  // Copy to clipboard
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  // ==================== RENDER ====================
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Brain className="w-8 h-8 text-purple-400" />
            <h1 className="text-4xl font-bold text-white">Clinical Decision Support</h1>
          </div>
          <p className="text-slate-400">
            AI-powered medical guidance using LLM + RAG (Retrieval Augmented Generation)
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-slate-700">
          <button
            onClick={() => setActiveTab('rag')}
            className={`px-6 py-3 font-medium border-b-2 transition-colors ${
              activeTab === 'rag'
                ? 'border-purple-500 text-purple-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            📚 Medical Knowledge (RAG)
          </button>
          <button
            onClick={() => setActiveTab('pathway')}
            className={`px-6 py-3 font-medium border-b-2 transition-colors ${
              activeTab === 'pathway'
                ? 'border-purple-500 text-purple-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            🔄 Clinical Pathway (LLM + RAG)
          </button>
          <button
            onClick={() => setActiveTab('analysis')}
            className={`px-6 py-3 font-medium border-b-2 transition-colors ${
              activeTab === 'analysis'
                ? 'border-purple-500 text-purple-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            ⚡ Complete Analysis
          </button>
        </div>

        {/* ==================== RAG TAB ==================== */}
        {activeTab === 'rag' && (
          <div className="space-y-6">
            <Card
              title="Medical Knowledge Base Query"
              icon={<Brain className="w-5 h-5 text-purple-400" />}
            >
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-200 mb-2">
                    Ask a Medical Question
                  </label>
                  <textarea
                    value={ragQuery}
                    onChange={(e) => setRagQuery(e.target.value)}
                    placeholder="e.g., What are the treatment options for acute myocardial infarction in elderly patients?"
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-purple-500 focus:outline-none"
                    rows="4"
                  />
                </div>
                <Button
                  onClick={handleRagQuery}
                  disabled={ragLoading}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {ragLoading ? (
                    <>
                      <Loader className="w-4 h-4 animate-spin mr-2" />
                      Searching Knowledge Base...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Query Medical Knowledge
                    </>
                  )}
                </Button>
              </div>
            </Card>

            {/* RAG Results */}
            {ragResults && (
              <Card title="Retrieved Medical Information" icon={<CheckCircle className="w-5 h-5 text-green-400" />}>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-semibold text-slate-200 mb-2">Confidence Score</h4>
                    <div className="w-full bg-slate-700 rounded-full h-2">
                      <div
                        className="bg-green-500 h-2 rounded-full transition-all"
                        style={{
                          width: `${(ragResults.confidence_score || 0) * 100}%`,
                        }}
                      />
                    </div>
                    <p className="text-sm text-slate-400 mt-1">
                      {((ragResults.confidence_score || 0) * 100).toFixed(1)}%
                    </p>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-slate-200 mb-2">Retrieved Documents</h4>
                    <div className="space-y-2">
                      {ragResults.retrieved_documents && ragResults.retrieved_documents.map((doc, idx) => (
                        <div key={idx} className="bg-slate-700/30 p-3 rounded border border-slate-600">
                          <p className="text-sm text-slate-200">{doc.content}</p>
                          <p className="text-xs text-slate-500 mt-2">Score: {(doc.score || 0).toFixed(3)}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-slate-200 mb-2">LLM Response</h4>
                    <div className="bg-slate-700/30 p-4 rounded border border-slate-600">
                      <p className="text-sm text-slate-200 whitespace-pre-wrap">
                        {ragResults.llm_response || 'No response generated'}
                      </p>
                    </div>
                  </div>

                  <Button
                    onClick={() => copyToClipboard(ragResults.llm_response || '')}
                    className="w-full bg-slate-700 hover:bg-slate-600"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Response
                  </Button>
                </div>
              </Card>
            )}

            {/* Query History */}
            {ragHistory.length > 0 && (
              <Card title="Query History">
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {ragHistory.map((item, idx) => (
                    <div
                      key={idx}
                      className="text-sm p-2 bg-slate-700/30 rounded cursor-pointer hover:bg-slate-700/50 transition-colors"
                      onClick={() => {
                        setRagQuery(item.query);
                        setRagResults(item.result);
                      }}
                    >
                      <p className="text-slate-200 truncate">{item.query}</p>
                      <p className="text-xs text-slate-500">{new Date(item.timestamp).toLocaleTimeString()}</p>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>
        )}

        {/* ==================== PATHWAY TAB ==================== */}
        {activeTab === 'pathway' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Input Card */}
              <Card title="Patient Vital Signs" icon={<Heart className="w-5 h-5 text-red-400" />}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Heart Rate (bpm)</label>
                    <input
                      type="number"
                      value={pathwayData.heart_rate}
                      onChange={(e) => setPathwayData({ ...pathwayData, heart_rate: e.target.value })}
                      placeholder="e.g., 78"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Blood Pressure (mmHg)</label>
                    <input
                      type="text"
                      value={pathwayData.blood_pressure}
                      onChange={(e) => setPathwayData({ ...pathwayData, blood_pressure: e.target.value })}
                      placeholder="e.g., 120/80"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Temperature (°C)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={pathwayData.temperature}
                      onChange={(e) => setPathwayData({ ...pathwayData, temperature: e.target.value })}
                      placeholder="e.g., 37.5"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">O2 Saturation (%)</label>
                    <input
                      type="number"
                      value={pathwayData.oxygen_saturation}
                      onChange={(e) => setPathwayData({ ...pathwayData, oxygen_saturation: e.target.value })}
                      placeholder="e.g., 98"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Respiratory Rate</label>
                    <input
                      type="number"
                      value={pathwayData.respiratory_rate}
                      onChange={(e) => setPathwayData({ ...pathwayData, respiratory_rate: e.target.value })}
                      placeholder="e.g., 16"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Age</label>
                    <input
                      type="number"
                      value={pathwayData.patient_age}
                      onChange={(e) => setPathwayData({ ...pathwayData, patient_age: e.target.value })}
                      placeholder="e.g., 65"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Gender</label>
                    <select
                      value={pathwayData.patient_gender}
                      onChange={(e) => setPathwayData({ ...pathwayData, patient_gender: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    >
                      <option value="M">Male</option>
                      <option value="F">Female</option>
                      <option value="O">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Emergency Level</label>
                    <select
                      value={pathwayData.emergency_level}
                      onChange={(e) => setPathwayData({ ...pathwayData, emergency_level: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                      <option value="critical">Critical</option>
                    </select>
                  </div>
                </div>
              </Card>

              {/* Clinical Data Card */}
              <Card title="Clinical Information" icon={<AlertCircle className="w-5 h-5 text-orange-400" />}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Symptoms (comma-separated)</label>
                    <textarea
                      value={pathwayData.symptoms}
                      onChange={(e) => setPathwayData({ ...pathwayData, symptoms: e.target.value })}
                      placeholder="e.g., chest pain, shortness of breath"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                      rows="3"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Medical History (comma-separated)</label>
                    <textarea
                      value={pathwayData.medical_history}
                      onChange={(e) => setPathwayData({ ...pathwayData, medical_history: e.target.value })}
                      placeholder="e.g., hypertension, diabetes"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                      rows="3"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Allergies (comma-separated)</label>
                    <input
                      type="text"
                      value={pathwayData.allergies}
                      onChange={(e) => setPathwayData({ ...pathwayData, allergies: e.target.value })}
                      placeholder="e.g., Penicillin, NSAIDs"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Current Medications (comma-separated)</label>
                    <textarea
                      value={pathwayData.current_medications}
                      onChange={(e) => setPathwayData({ ...pathwayData, current_medications: e.target.value })}
                      placeholder="e.g., Lisinopril 10mg daily, Metformin 500mg BID"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                      rows="3"
                    />
                  </div>

                  <Button
                    onClick={handlePathwayGenerate}
                    disabled={pathwayLoading}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    {pathwayLoading ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin mr-2" />
                        Generating Pathway...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Generate Clinical Pathway
                      </>
                    )}
                  </Button>
                </div>
              </Card>
            </div>

            {/* Pathway Results */}
            {pathway && (
              <Card title="Generated Clinical Pathway" icon={<CheckCircle className="w-5 h-5 text-green-400" />}>
                <div className="space-y-4">
                  {pathway.recommendation && (
                    <div>
                      <h4 className="text-sm font-semibold text-slate-200 mb-2">Primary Recommendation</h4>
                      <div className="bg-green-900/30 border border-green-700 p-4 rounded">
                        <p className="text-sm text-green-200">{pathway.recommendation}</p>
                      </div>
                    </div>
                  )}

                  {pathway.next_steps && (
                    <div>
                      <h4 className="text-sm font-semibold text-slate-200 mb-2">Next Steps</h4>
                      <ol className="space-y-2 list-decimal list-inside">
                        {pathway.next_steps.map((step, idx) => (
                          <li key={idx} className="text-sm text-slate-300">
                            {step}
                          </li>
                        ))}
                      </ol>
                    </div>
                  )}

                  {pathway.warnings && pathway.warnings.length > 0 && (
                    <div>
                      <h4 className="text-sm font-semibold text-slate-200 mb-2">⚠️ Warnings</h4>
                      <div className="space-y-2">
                        {pathway.warnings.map((warning, idx) => (
                          <div key={idx} className="bg-orange-900/30 border border-orange-700 p-3 rounded">
                            <p className="text-sm text-orange-200">{warning}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {pathway.rag_sources && (
                    <div>
                      <h4 className="text-sm font-semibold text-slate-200 mb-2">📚 Medical Sources (RAG)</h4>
                      <div className="space-y-2">
                        {pathway.rag_sources.map((source, idx) => (
                          <div key={idx} className="bg-slate-700/30 p-2 rounded text-xs text-slate-300">
                            {source}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <Button
                    onClick={() => copyToClipboard(JSON.stringify(pathway, null, 2))}
                    className="w-full bg-slate-700 hover:bg-slate-600"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Pathway
                  </Button>
                </div>
              </Card>
            )}
          </div>
        )}

        {/* ==================== ANALYSIS TAB ==================== */}
        {activeTab === 'analysis' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Input Card */}
              <Card title="Chief Complaint & Vitals" icon={<Heart className="w-5 h-5 text-red-400" />}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Chief Complaint</label>
                    <textarea
                      value={analysisData.chief_complaint}
                      onChange={(e) => setAnalysisData({ ...analysisData, chief_complaint: e.target.value })}
                      placeholder="e.g., Severe chest pain for 30 minutes"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                      rows="2"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Heart Rate (bpm)</label>
                    <input
                      type="number"
                      value={analysisData.heart_rate}
                      onChange={(e) => setAnalysisData({ ...analysisData, heart_rate: e.target.value })}
                      placeholder="e.g., 92"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Blood Pressure (mmHg)</label>
                    <input
                      type="text"
                      value={analysisData.blood_pressure}
                      onChange={(e) => setAnalysisData({ ...analysisData, blood_pressure: e.target.value })}
                      placeholder="e.g., 145/95"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Temperature (°C)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={analysisData.temperature}
                      onChange={(e) => setAnalysisData({ ...analysisData, temperature: e.target.value })}
                      placeholder="e.g., 37.2"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">O2 Saturation (%)</label>
                    <input
                      type="number"
                      value={analysisData.oxygen_saturation}
                      onChange={(e) => setAnalysisData({ ...analysisData, oxygen_saturation: e.target.value })}
                      placeholder="e.g., 96"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Respiratory Rate</label>
                    <input
                      type="number"
                      value={analysisData.respiratory_rate}
                      onChange={(e) => setAnalysisData({ ...analysisData, respiratory_rate: e.target.value })}
                      placeholder="e.g., 18"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Age</label>
                    <input
                      type="number"
                      value={analysisData.patient_age}
                      onChange={(e) => setAnalysisData({ ...analysisData, patient_age: e.target.value })}
                      placeholder="e.g., 58"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Gender</label>
                    <select
                      value={analysisData.patient_gender}
                      onChange={(e) => setAnalysisData({ ...analysisData, patient_gender: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    >
                      <option value="M">Male</option>
                      <option value="F">Female</option>
                      <option value="O">Other</option>
                    </select>
                  </div>
                </div>
              </Card>

              {/* Medical History Card */}
              <Card title="Medical Background" icon={<AlertCircle className="w-5 h-5 text-orange-400" />}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Symptoms (comma-separated)</label>
                    <textarea
                      value={analysisData.symptoms}
                      onChange={(e) => setAnalysisData({ ...analysisData, symptoms: e.target.value })}
                      placeholder="e.g., chest pain, shortness of breath, diaphoresis"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                      rows="3"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Medical History (comma-separated)</label>
                    <textarea
                      value={analysisData.medical_history}
                      onChange={(e) => setAnalysisData({ ...analysisData, medical_history: e.target.value })}
                      placeholder="e.g., coronary artery disease, hypertension, type 2 diabetes"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                      rows="3"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Allergies (comma-separated)</label>
                    <input
                      type="text"
                      value={analysisData.allergies}
                      onChange={(e) => setAnalysisData({ ...analysisData, allergies: e.target.value })}
                      placeholder="e.g., Penicillin, NSAIDs"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-200 mb-1">Current Medications (comma-separated)</label>
                    <textarea
                      value={analysisData.current_medications}
                      onChange={(e) => setAnalysisData({ ...analysisData, current_medications: e.target.value })}
                      placeholder="e.g., Aspirin 325mg daily, Metoprolol 50mg BID, Lisinopril 10mg daily"
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded text-white text-sm"
                      rows="3"
                    />
                  </div>

                  <Button
                    onClick={handleAnalyze}
                    disabled={analysisLoading}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    {analysisLoading ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin mr-2" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Run Complete Analysis
                      </>
                    )}
                  </Button>
                </div>
              </Card>
            </div>

            {/* Analysis Results */}
            {analysis && (
              <div className="space-y-6">
                {analysis.summary && (
                  <Card title="Clinical Summary" icon={<CheckCircle className="w-5 h-5 text-blue-400" />}>
                    <div className="bg-blue-900/30 border border-blue-700 p-4 rounded">
                      <p className="text-sm text-blue-200 whitespace-pre-wrap">{analysis.summary}</p>
                    </div>
                  </Card>
                )}

                {analysis.differential_diagnoses && (
                  <Card title="Differential Diagnoses" icon={<Zap className="w-5 h-5 text-yellow-400" />}>
                    <div className="space-y-3">
                      {analysis.differential_diagnoses.map((diagnosis, idx) => (
                        <div key={idx} className="bg-slate-700/30 p-3 rounded border border-slate-600">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-semibold text-slate-200">{diagnosis.diagnosis}</h4>
                            <span className="text-xs bg-yellow-500/20 text-yellow-200 px-2 py-1 rounded">
                              {(diagnosis.probability * 100).toFixed(0)}%
                            </span>
                          </div>
                          {diagnosis.reasoning && (
                            <p className="text-xs text-slate-400">{diagnosis.reasoning}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </Card>
                )}

                {analysis.investigations && (
                  <Card title="Recommended Investigations" icon={<Settings className="w-5 h-5 text-cyan-400" />}>
                    <ul className="space-y-2 list-disc list-inside">
                      {analysis.investigations.map((inv, idx) => (
                        <li key={idx} className="text-sm text-slate-300">
                          {inv}
                        </li>
                      ))}
                    </ul>
                  </Card>
                )}

                {analysis.treatment_recommendations && (
                  <Card title="Treatment Recommendations" icon={<CheckCircle className="w-5 h-5 text-green-400" />}>
                    <div className="space-y-3">
                      {analysis.treatment_recommendations.map((rec, idx) => (
                        <div key={idx} className="bg-green-900/30 border border-green-700 p-3 rounded">
                          <p className="text-sm text-green-200">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </Card>
                )}

                {analysis.monitoring_parameters && (
                  <Card title="Monitoring Parameters" icon={<Heart className="w-5 h-5 text-red-400" />}>
                    <ul className="space-y-2 list-disc list-inside">
                      {analysis.monitoring_parameters.map((param, idx) => (
                        <li key={idx} className="text-sm text-slate-300">
                          {param}
                        </li>
                      ))}
                    </ul>
                  </Card>
                )}

                {analysis.warnings && analysis.warnings.length > 0 && (
                  <Card title="⚠️ Critical Warnings" icon={<AlertCircle className="w-5 h-5 text-red-400" />}>
                    <div className="space-y-2">
                      {analysis.warnings.map((warning, idx) => (
                        <div key={idx} className="bg-red-900/30 border border-red-700 p-3 rounded">
                          <p className="text-sm text-red-200">{warning}</p>
                        </div>
                      ))}
                    </div>
                  </Card>
                )}

                <Button
                  onClick={() => copyToClipboard(JSON.stringify(analysis, null, 2))}
                  className="w-full bg-slate-700 hover:bg-slate-600"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Full Analysis
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
