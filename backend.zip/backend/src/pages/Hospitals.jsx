import { useState } from 'react';
import Navbar from '../components/common/Navbar';
import Sidebar from '../components/common/Sidebar';
import { MapPin, Bed } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Hospitals() {
  const [latitude, setLatitude] = useState(28.6139);
  const [longitude, setLongitude] = useState(77.209);
  const [radius, setRadius] = useState(10);

  const hospitals = [
    {
      id: 1,
      name: 'City Hospital',
      distance: 2.5,
      icu: 5,
      general: 15,
      emergency: 3,
      specs: ['Cardiology', 'Neurology'],
    },
    {
      id: 2,
      name: 'Metro Medical Center',
      distance: 5.8,
      icu: 8,
      general: 20,
      emergency: 4,
      specs: ['Orthopedics', 'Pediatrics'],
    },
    {
      id: 3,
      name: 'Advanced Care Hospital',
      distance: 7.2,
      icu: 6,
      general: 18,
      emergency: 5,
      specs: ['Trauma', 'General Surgery'],
    },
  ];

  const handleSearch = () => {
    toast.success(`Found ${hospitals.length} hospitals nearby`);
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        <main className="flex-1 overflow-auto p-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-900 mb-8">🏥 Find Nearby Hospitals</h1>

            <div className="bg-white rounded-lg shadow p-6 mb-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Latitude</label>
                  <input
                    type="number"
                    value={latitude}
                    onChange={(e) => setLatitude(parseFloat(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Longitude</label>
                  <input
                    type="number"
                    value={longitude}
                    onChange={(e) => setLongitude(parseFloat(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Radius (km)</label>
                  <input
                    type="number"
                    value={radius}
                    onChange={(e) => setRadius(parseInt(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
                <div className="flex items-end">
                  <button
                    onClick={handleSearch}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg"
                  >
                    Search
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {hospitals.map((hospital) => (
                <div key={hospital.id} className="bg-white rounded-lg shadow hover:shadow-lg transition p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">{hospital.name}</h3>

                  <div className="space-y-3 text-sm text-gray-600 mb-4">
                    <div className="flex items-center gap-2">
                      <MapPin size={16} className="text-red-500" />
                      <span>{hospital.distance.toFixed(1)} km away</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-3 border-t">
                      <div className="text-center">
                        <div className="text-lg font-bold text-blue-600">{hospital.icu}</div>
                        <div className="text-xs">ICU Beds</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-green-600">{hospital.general}</div>
                        <div className="text-xs">General</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-orange-600">{hospital.emergency}</div>
                        <div className="text-xs">Emergency</div>
                      </div>
                    </div>

                    <div className="pt-3 border-t">
                      <p className="font-semibold text-gray-700 mb-2">Specializations:</p>
                      <div className="flex flex-wrap gap-1">
                        {hospital.specs.map((spec) => (
                          <span key={spec} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg">
                    Reserve Bed
                  </button>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
