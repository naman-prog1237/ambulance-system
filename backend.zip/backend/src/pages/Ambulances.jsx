import { useState } from 'react';
import Navbar from '../components/common/Navbar';
import Sidebar from '../components/common/Sidebar';
import { MapPin, AlertCircle, Zap } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Ambulances() {
  const [ambulances] = useState([
    {
      id: 'A-001',
      driver: 'Rajesh Kumar',
      location: 'Route 5, Near Hospital',
      status: 'active',
      fuel: 85,
      lat: 28.61,
      lon: 77.2,
    },
    {
      id: 'A-002',
      driver: 'Priya Singh',
      location: 'Downtown Medical',
      status: 'dispatch',
      fuel: 60,
      lat: 28.63,
      lon: 77.22,
    },
    {
      id: 'A-003',
      driver: 'Amit Patel',
      location: 'Base Station',
      status: 'idle',
      fuel: 100,
      lat: 28.64,
      lon: 77.21,
    },
  ]);

  const handleToggleSiren = (id) => {
    toast.success(`Siren toggled for ${id}`);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'text-green-600 bg-green-50';
      case 'dispatch':
        return 'text-orange-600 bg-orange-50';
      case 'idle':
        return 'text-gray-600 bg-gray-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        <main className="flex-1 overflow-auto p-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-900 mb-8">🚑 Ambulance Fleet Management</h1>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white rounded-lg shadow p-4">
                <p className="text-gray-600 text-sm">Active Ambulances</p>
                <p className="text-3xl font-bold text-green-600 mt-2">12</p>
              </div>
              <div className="bg-white rounded-lg shadow p-4">
                <p className="text-gray-600 text-sm">In Dispatch</p>
                <p className="text-3xl font-bold text-orange-600 mt-2">3</p>
              </div>
              <div className="bg-white rounded-lg shadow p-4">
                <p className="text-gray-600 text-sm">Idle/Available</p>
                <p className="text-3xl font-bold text-blue-600 mt-2">7</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {ambulances.map((ambulance) => (
                <div key={ambulance.id} className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">{ambulance.id}</h3>
                      <p className="text-sm text-gray-500">{ambulance.driver}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(ambulance.status)}`}>
                      {ambulance.status.toUpperCase()}
                    </span>
                  </div>

                  <div className="space-y-3 mb-4">
                    <div className="flex items-center gap-2 text-gray-600">
                      <MapPin size={16} className="text-red-500" />
                      <span className="text-sm">{ambulance.location}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <Zap size={16} className="text-yellow-500" />
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${ambulance.fuel > 50 ? 'bg-green-500' : 'bg-orange-500'}`}
                          style={{ width: `${ambulance.fuel}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600">{ambulance.fuel}%</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 rounded-lg text-sm">
                      Track
                    </button>
                    <button
                      onClick={() => handleToggleSiren(ambulance.id)}
                      className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-3 rounded-lg text-sm flex items-center justify-center gap-1"
                    >
                      <AlertCircle size={16} />
                      Siren
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
