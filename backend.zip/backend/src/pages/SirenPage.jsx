import React, { useState } from 'react';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';
import { Siren, Zap } from 'lucide-react';
import { sirenAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function SirenPage() {
  const [formData, setFormData] = useState({
    ambulance_id: '',
    enable: true,
    siren_type: 'standard',
  });
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.ambulance_id) {
      toast.error('Ambulance ID is required');
      return;
    }

    setLoading(true);
    try {
      const res = await sirenAPI.toggleSiren({
        ambulance_id: formData.ambulance_id,
        enable: formData.enable,
        siren_type: formData.siren_type,
      });
      setStatus(res.data);
      toast.success('Siren state updated');
    } catch {
      toast.error('Failed to toggle siren');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Siren className="w-8 h-8 text-red-600" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Ambulance Siren Control</h1>
          <p className="text-gray-600">Remotely manage siren state and monitor power usage.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form */}
        <Card className="lg:col-span-1">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Ambulance ID"
              name="ambulance_id"
              value={formData.ambulance_id}
              onChange={handleChange}
              placeholder="AMB-001"
            />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Siren Type
              </label>
              <select
                name="siren_type"
                value={formData.siren_type}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 shadow-neumorphic focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="standard">Standard</option>
                <option value="high_priority">High Priority</option>
                <option value="silent">Silent (lights only)</option>
              </select>
            </div>
            <label className="inline-flex items-center space-x-2 text-sm text-gray-700">
              <input
                type="checkbox"
                name="enable"
                checked={formData.enable}
                onChange={handleChange}
                className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
              />
              <span>Turn siren ON</span>
            </label>
            <Button type="submit" loading={loading} className="w-full">
              <Zap className="w-4 h-4 mr-2" />
              Apply Siren State
            </Button>
          </form>
        </Card>

        {/* Result */}
        <Card className="lg:col-span-1">
          {status ? (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Current Siren Status</h2>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Ambulance</p>
                  <p className="font-semibold">{status.ambulance_id}</p>
                </div>
                <div>
                  <p className="text-gray-500">Status</p>
                  <p
                    className={`font-semibold ${
                      status.status === 'on' ? 'text-red-600' : 'text-gray-700'
                    }`}
                  >
                    {status.status.toUpperCase()}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Power Usage</p>
                  <p className="font-semibold">
                    {status.power_consumption_watts} W
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Updated At</p>
                  <p className="font-semibold">
                    {new Date(status.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-400">
              Toggle the siren to see live status here.
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
