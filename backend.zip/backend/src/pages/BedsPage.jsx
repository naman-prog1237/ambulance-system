import React, { useState } from 'react';
import Card from '../components/Card';
import Input from '../components/Input';
import Button from '../components/Button';
import { BedDouble } from 'lucide-react';
import { bedsAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function BedsPage() {
  const [formData, setFormData] = useState({
    patient_id: '',
    hospital_id: '',
    bed_type: 'ICU',
    reason: '',
    estimated_stay_hours: 24,
  });
  const [loading, setLoading] = useState(false);
  const [reservation, setReservation] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'estimated_stay_hours' ? Number(value) : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.patient_id || !formData.hospital_id || !formData.reason) {
      toast.error('Please fill all required fields');
      return;
    }
    setLoading(true);
    try {
      const res = await bedsAPI.reserveBed(formData);
      setReservation(res.data);
      toast.success('Bed reserved successfully');
    } catch {
      toast.error('Failed to reserve bed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <BedDouble className="w-8 h-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Bed Management</h1>
          <p className="text-gray-600">Reserve hospital beds for incoming patients.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form */}
        <Card className="lg:col-span-1">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Patient ID"
              name="patient_id"
              value={formData.patient_id}
              onChange={handleChange}
              placeholder="PAT-001"
            />
            <Input
              label="Hospital ID"
              name="hospital_id"
              value={formData.hospital_id}
              onChange={handleChange}
              placeholder="HOSP-001"
            />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bed Type
              </label>
              <select
                name="bed_type"
                value={formData.bed_type}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 shadow-neumorphic focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="ICU">ICU</option>
                <option value="general">General</option>
                <option value="emergency">Emergency</option>
              </select>
            </div>
            <Input
              label="Reason for admission"
              name="reason"
              value={formData.reason}
              onChange={handleChange}
              placeholder="Chest pain, trauma, etc."
            />
            <Input
              label="Estimated stay (hours)"
              name="estimated_stay_hours"
              type="number"
              value={formData.estimated_stay_hours}
              onChange={handleChange}
            />
            <Button type="submit" loading={loading} className="w-full">
              Reserve Bed
            </Button>
          </form>
        </Card>

        {/* Result */}
        <Card className="lg:col-span-1">
          {reservation ? (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">
                Reservation Details
              </h2>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Reservation ID</p>
                  <p className="font-semibold">{reservation.reservation_id}</p>
                </div>
                <div>
                  <p className="text-gray-500">Bed ID</p>
                  <p className="font-semibold">{reservation.bed_id}</p>
                </div>
                <div>
                  <p className="text-gray-500">Bed Type</p>
                  <p className="font-semibold">{reservation.bed_type}</p>
                </div>
                <div>
                  <p className="text-gray-500">Status</p>
                  <p className="font-semibold">{reservation.status}</p>
                </div>
                <div>
                  <p className="text-gray-500">Reserved At</p>
                  <p className="font-semibold">
                    {new Date(reservation.reserved_at).toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Expected Arrival</p>
                  <p className="font-semibold">
                    {new Date(reservation.expected_arrival).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-400">
              Fill the form and reserve a bed to see details here.
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
