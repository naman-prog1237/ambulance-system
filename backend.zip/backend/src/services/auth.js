import apiClient from './api';
import { endpoints } from './endpoints';

export const authService = {
  register: async (userData) => {
    const response = await apiClient.post(endpoints.auth.register, userData);
    return response.data;
  },

  login: async (credentials) => {
    const response = await apiClient.post(endpoints.auth.login, credentials);
    if (response.data.access_token) {
      localStorage.setItem('access_token', response.data.access_token);
      localStorage.setItem('token_type', response.data.token_type);
    }
    return response.data;
  },

  logout: () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
    localStorage.removeItem('token_type');
  },

  getToken: () => localStorage.getItem('access_token'),

  isAuthenticated: () => !!localStorage.getItem('access_token'),
};
