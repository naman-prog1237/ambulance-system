export const endpoints = {
  auth: {
    register: '/api/auth/register',
    login: '/api/auth/login',
  },
  vitals: {
    update: '/api/vitals/update',
  },
  beds: {
    reserve: '/api/beds/reserve',
  },
  hospitals: {
    search: '/api/hospitals/search',
  },
  routes: {
    optimize: '/api/route/optimize',
  },
  siren: {
    toggle: '/api/siren/toggle',
  },
  alerts: {
    sms: '/api/alerts/sms',
    insurance: '/api/insurance/alert',
  },
  rag: {
    query: '/api/rag/query',
    generatePathway: '/api/pathways/generate-with-rag',
  },
  health: '/health',
};
