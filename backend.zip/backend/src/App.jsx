export default function App() {
  return (
    <div style={{ padding: 40, fontSize: 24 }}>
      <h1>React is working 🎯</h1>
    </div>
  );
}
