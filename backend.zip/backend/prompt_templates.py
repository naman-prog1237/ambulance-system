# FILE 2: backend/prompt_templates.py
"""
Medical Prompt Templates for LLM-powered pathway generation
Engineered for clinical accuracy and safety
"""

from langchain.prompts import PromptTemplate
import logging

logger = logging.getLogger(__name__)


class MedicalPromptTemplates:
    """Collection of medical prompts for LLM reasoning"""
    
    # Clinical Decision Support Prompt
    CLINICAL_PATHWAY_PROMPT = PromptTemplate(
        input_variables=["patient_vitals", "symptoms", "medical_history", "guidelines"],
        template="""
You are an AI clinical decision support system assisting paramedics and emergency physicians.

## PATIENT PRESENTATION:
Vitals: {patient_vitals}
Symptoms: {symptoms}
Medical History: {medical_history}

## RELEVANT CLINICAL GUIDELINES:
{guidelines}

## TASK:
Generate a structured clinical care pathway with:

1. **Severity Assessment**: Classify as STABLE, WARNING, or CRITICAL
2. **Clinical Summary**: Concise 2-3 sentence patient summary
3. **Ranked Actions**: Steps in priority order (HIGH→MEDIUM→LOW urgency)
4. **Confidence Score**: 0-1 confidence in your assessment
5. **Monitoring Parameters**: What to watch continuously
6. **Next Review**: Minutes until reassessment

## FORMAT (STRICT JSON):
{{
  "severity": "STABLE|WARNING|CRITICAL",
  "overall_confidence": 0.85,
  "clinical_summary": "Patient presenting with... indicating...",
  "actions": [
    {{
      "step_number": 1,
      "action": "Specific clinical action",
      "urgency": "high|medium|low",
      "time_frame_minutes": 5,
      "responsible_party": "Paramedic|Doctor|Nurse",
      "prerequisites": [],
      "monitoring_parameters": ["HR", "BP", "SpO2"]
    }}
  ],
  "rag_sources": ["guideline_id_1", "guideline_id_2"],
  "warnings": ["Warning 1", "Warning 2"],
  "recommendations": ["Rec 1", "Rec 2"],
  "next_review_minutes": 5
}}

## CRITICAL RULES:
- NEVER recommend actions outside standard protocols
- ALWAYS include fallback if resources unavailable
- Base decisions ONLY on provided guidelines
- Be conservative: when in doubt, escalate
- Confidence should reflect data quality (↓ if missing info)
"""
    )
    
    # Condition-Specific Reasoning
    ACS_PATHWAY_PROMPT = PromptTemplate(
        input_variables=["ecg_findings", "troponin", "vitals", "symptoms"],
        template="""
ACUTE CORONARY SYNDROME ASSESSMENT

ECG Findings: {ecg_findings}
Troponin Level: {troponin}
Vital Signs: {vitals}
Symptoms: {symptoms}

Assess for ACS using TIMI and HEART scores.
Generate immediate management pathway per ACC/AHA guidelines.
Include PCI vs fibrinolysis decision tree if applicable.
"""
    )
    
    # Sepsis Bundle
    SEPSIS_PATHWAY_PROMPT = PromptTemplate(
        input_variables=["fever", "lactate", "bp", "wbc", "suspected_source"],
        template="""
SEPSIS MANAGEMENT PROTOCOL

Fever: {fever}
Lactate: {lactate}
Blood Pressure: {bp}
WBC: {wbc}
Suspected Source: {suspected_source}

Generate sepsis bundle per Surviving Sepsis Campaign.
Include fluid bolus, antibiotic selection, source control, and vasopressor initiation if needed.
"""
    )
    
    # Stroke Assessment
    STROKE_PATHWAY_PROMPT = PromptTemplate(
        input_variables=["time_onset", "nihss_score", "imaging", "glucose", "vitals"],
        template="""
ACUTE ISCHEMIC STROKE ASSESSMENT

Time from Onset: {time_onset}
NIHSS Score: {nihss_score}
Imaging: {imaging}
Glucose: {glucose}
Vital Signs: {vitals}

Determine if patient is candidate for:
1. IV thrombolysis (alteplase)
2. Mechanical thrombectomy
3. Supportive care

Generate timeline and medication dosing.
"""
    )
    
    # Trauma Assessment
    TRAUMA_PATHWAY_PROMPT = PromptTemplate(
        input_variables=["mechanism", "vitals", "injuries", "gcs"],
        template="""
TRAUMA ASSESSMENT

Mechanism of Injury: {mechanism}
Vital Signs: {vitals}
Injuries Identified: {injuries}
Glasgow Coma Scale: {gcs}

Calculate ISS score, generate ATLS protocol pathway.
Include hemorrhage control, airway management, and transport decisions.
"""
    )
    
    @staticmethod
    def get_clinical_pathway_template():
        """Get clinical pathway template"""
        return MedicalPromptTemplates.CLINICAL_PATHWAY_PROMPT
    
    @staticmethod
    def get_condition_specific_template(condition: str):
        """Get condition-specific template"""
        condition_lower = condition.lower()
        
        if "acs" in condition_lower or "chest pain" in condition_lower:
            return MedicalPromptTemplates.ACS_PATHWAY_PROMPT
        elif "sepsis" in condition_lower:
            return MedicalPromptTemplates.SEPSIS_PATHWAY_PROMPT
        elif "stroke" in condition_lower:
            return MedicalPromptTemplates.STROKE_PATHWAY_PROMPT
        elif "trauma" in condition_lower:
            return MedicalPromptTemplates.TRAUMA_PATHWAY_PROMPT
        else:
            return MedicalPromptTemplates.CLINICAL_PATHWAY_PROMPT


class SafetyPrompts:
    """Safety-focused prompts"""
    
    CONTRAINDICATION_CHECK = """
Before providing the pathway, verify:
1. Patient is not allergic to recommended medications
2. Medications don't interact with current drugs
3. Dosing is appropriate for age/weight
4. No absolute contraindications present
5. Required equipment is available

Flag any concerns as HIGH-PRIORITY WARNINGS.
"""
    
    FALLBACK_REASONING = """
If the recommended treatment is unavailable:
1. What is the next-best alternative?
2. Can we provide equivalent supportive care?
3. What is the escalation path?
4. When should we escalate to higher level of care?

Always provide a viable fallback pathway.
"""


# Prompt engineering utilities
def format_clinical_context(vitals: dict, symptoms: dict, history: list) -> str:
    """Format clinical context for prompts"""
    vitals_str = "\n".join([f"  {k}: {v}" for k, v in vitals.items()])
    symptoms_str = "\n".join([f"  - {s}" for s in symptoms.get('symptoms', [])])
    history_str = "\n".join([f"  - {h}" for h in history])
    
    return f"""
VITALS:
{vitals_str}

SYMPTOMS:
{symptoms_str}

MEDICAL HISTORY:
{history_str}
"""


def build_rag_context(retrieved_docs: list) -> str:
    """Build RAG context from retrieved documents"""
    context = "RELEVANT CLINICAL GUIDELINES:\n\n"
    
    for i, (doc, score) in enumerate(retrieved_docs, 1):
        title = doc.metadata.get('title', 'Guideline')
        source = doc.metadata.get('source', 'Unknown')
        content = doc.page_content[:500]  # First 500 chars
        
        context += f"""
## {i}. {title} (Confidence: {score:.2f})
Source: {source}

{content}
...
---
"""
    
    return context
