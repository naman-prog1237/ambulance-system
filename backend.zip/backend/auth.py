"""
CORRECTED AUTH.PY - BCRYPT DIRECT IMPLEMENTATION
=================================================
This version uses bcrypt directly (no passlib dependency)
Fixes all library version conflicts

FIXES:
✅ No passlib dependency issues
✅ Direct bcrypt usage (bcrypt==4.0.1)
✅ Proper 72-byte UTF-8 truncation
✅ Password verification with same logic
✅ No library conflicts
"""

from datetime import datetime, timedelta
from typing import Optional, Dict
from jose import JWTError, jwt
import bcrypt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from config import settings
from models import UserRole, TokenResponse
import logging

logger = logging.getLogger(__name__)

# Security
security = HTTPBearer()


class AuthService:
    """JWT authentication and password hashing service - BCRYPT DIRECT"""

    def __init__(self):
        self.secret_key = settings.SECRET_KEY
        self.algorithm = settings.ALGORITHM
        self.access_token_expire_minutes = settings.ACCESS_TOKEN_EXPIRE_MINUTES

    def hash_password(self, password: str) -> str:
        """
        Hash password with bcrypt directly - NO PASSLIB
        
        CRITICAL FIX: Truncate at UTF-8 BYTE level, not character level
        This prevents: ValueError: password cannot be longer than 72 bytes
        
        Args:
            password: Plain text password to hash
            
        Returns:
            Hashed password string
        """
        try:
            # Handle None/empty passwords
            if password is None:
                password = ""
            
            # Convert to string
            password_str = str(password)
            
            # CRITICAL FIX: Encode to UTF-8 bytes, truncate to 72 bytes, then decode
            password_bytes = password_str.encode('utf-8')[:72]
            password_truncated = password_bytes.decode('utf-8', errors='ignore')
            
            logger.debug(
                f"Password hashing: original={len(password_str)} chars, "
                f"bytes={len(password_bytes)}, truncated={len(password_truncated)} chars"
            )
            
            # Generate salt and hash with bcrypt (rounds=12 for security)
            salt = bcrypt.gensalt(rounds=12)
            hashed = bcrypt.hashpw(password_truncated.encode('utf-8'), salt)
            
            # Decode bytes to string for storage
            hashed_str = hashed.decode('utf-8')
            logger.info("✅ Password hashed successfully with bcrypt")
            return hashed_str
            
        except Exception as e:
            logger.error(f"Error hashing password: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Password processing failed"
            )

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """
        Verify plain password against hash - BCRYPT DIRECT
        
        CRITICAL FIX: Apply SAME truncation logic as hash_password
        Must truncate at UTF-8 BYTE level for consistency
        
        Args:
            plain_password: Plain text password to verify
            hashed_password: Hash to verify against
            
        Returns:
            True if password matches, False otherwise
        """
        try:
            if plain_password is None:
                plain_password = ""
            
            password_str = str(plain_password)
            
            # CRITICAL FIX: Apply EXACT SAME truncation logic as hash_password
            password_bytes = password_str.encode('utf-8')[:72]
            password_truncated = password_bytes.decode('utf-8', errors='ignore')
            
            # Verify using bcrypt
            # bcrypt.checkpw expects bytes for both arguments
            result = bcrypt.checkpw(
                password_truncated.encode('utf-8'),
                hashed_password.encode('utf-8')
            )
            
            logger.debug(f"✅ Password verification result: {result}")
            return result
            
        except Exception as e:
            logger.error(f"Error verifying password: {str(e)}")
            return False

    def create_access_token(
        self, 
        data: Dict, 
        expires_delta: Optional[timedelta] = None
    ) -> TokenResponse:
        """
        Create JWT access token
        
        Args:
            data: Payload data to encode (e.g., user_id, email, role)
            expires_delta: Custom expiration time
            
        Returns:
            TokenResponse with JWT token
        """
        try:
            to_encode = data.copy()
            
            # Calculate expiration
            if expires_delta:
                expire = datetime.utcnow() + expires_delta
            else:
                expire = datetime.utcnow() + timedelta(
                    minutes=self.access_token_expire_minutes
                )
            
            # Add expiration to payload
            to_encode.update({"exp": expire})
            
            # Encode JWT
            encoded_jwt = jwt.encode(
                to_encode,
                self.secret_key,
                algorithm=self.algorithm
            )
            
            expires_in = int((expire - datetime.utcnow()).total_seconds())
            
            logger.info(f"✅ JWT token created, expires in {expires_in} seconds")
            
            return TokenResponse(
                access_token=encoded_jwt,
                token_type="bearer",
                expires_in=expires_in
            )
            
        except Exception as e:
            logger.error(f"Error creating token: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Token creation failed"
            )

    def verify_token(self, token: str) -> Dict:
        """
        Verify JWT token and return payload
        
        Args:
            token: JWT token string
            
        Returns:
            Decoded token payload
            
        Raises:
            HTTPException if token is invalid or expired
        """
        try:
            payload = jwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm]
            )
            logger.debug("✅ Token verified successfully")
            return payload
            
        except JWTError as e:
            logger.warning(f"Token verification failed: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token",
                headers={"WWW-Authenticate": "Bearer"}
            )

    def get_current_user(token: str):
        try:
            payload = decode_access_token(token)
            user_id = payload.get("sub")
            if not user_id:
                raise HTTPException(status_code=401, detail="Invalid token payload")
            user = get_user_by_id(user_id)  # your existing logic
            if not user:
                raise HTTPException(status_code=401, detail="User not found")
            return user
        except Exception as e:
            logger.error(f"Error extracting user from token: {e}")
            raise HTTPException(status_code=401, detail="Authentication failed")


class RoleBasedAccessControl:
    """Role-based access control for endpoints"""
    
    # Define permissions for each role
    ROLE_PERMISSIONS = {
        "admin": {"all_endpoints"},
        "doctor": {
            "read_patient_data",
            "generate_pathway",
            "view_fleet_status",
            "approve_transfers"
        },
        "paramedic": {
            "read_patient_data",
            "update_vitals",
            "update_location",
            "toggle_siren",
            "access_pathway"
        },
        "hospital_staff": {
            "read_patient_data",
            "manage_beds",
            "view_transfers",
            "access_pathway"
        },
        "patient": {
            "read_own_data",
            "view_pathway",
            "emergency_call"
        }
    }

    @staticmethod
    def require_role(*required_roles: str):
        """
        Decorator to require specific role(s)
        
        Args:
            *required_roles: One or more required role names
            
        Returns:
            FastAPI dependency function
        """
        async def check_role(
            credentials: HTTPAuthorizationCredentials = Depends(security)
        ) -> Dict:
            auth_service = AuthService()
            user = auth_service.get_current_user(credentials)
            
            if user["role"] not in required_roles:
                logger.warning(
                    f"Role check failed: user has {user['role']}, "
                    f"required {required_roles}"
                )
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Required roles: {list(required_roles)}"
                )
            return user
        
        return check_role

    @staticmethod
    def require_permission(permission: str):
        """
        Decorator to require specific permission
        
        Args:
            permission: Required permission name
            
        Returns:
            FastAPI dependency function
        """
        async def check_permission(
            credentials: HTTPAuthorizationCredentials = Depends(security)
        ) -> Dict:
            auth_service = AuthService()
            user = auth_service.get_current_user(credentials)
            role = user["role"]
            
            # Admin has all permissions
            if role == "admin":
                return user
            
            # Check if role has permission
            perms = RoleBasedAccessControl.ROLE_PERMISSIONS.get(role, set())
            if permission not in perms:
                logger.warning(
                    f"Permission check failed: user role {role} "
                    f"missing permission {permission}"
                )
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Missing permission: {permission}"
                )
            return user
        
        return check_permission


# ===== SINGLETON INSTANCES =====
auth_service = AuthService()
rbac = RoleBasedAccessControl()
