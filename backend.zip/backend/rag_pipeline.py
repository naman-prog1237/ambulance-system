# FILE 1: backend/rag_pipeline.py
# Complete RAG ingestion & retrieval pipeline

"""
RAG Pipeline - Complete Medical Document Ingestion & Retrieval
Handles: Loading, chunking, embedding, vector storage, and semantic search
"""

import os
import json
import logging
from typing import List, Dict, Optional, Any, Tuple
from datetime import datetime
from pathlib import Path

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.schema import Document

import faiss
import numpy as np
from config import settings

logger = logging.getLogger(__name__)


class MedicalDocumentLoader:
    """Load medical documents from multiple sources"""
    
    @staticmethod
    def load_medical_guidelines() -> List[Document]:
        """Load sample medical guidelines"""
        guidelines = [
            {
                "id": "hypertension_001",
                "title": "Hypertension Management Protocol",
                "content": """
HYPERTENSION MANAGEMENT - COMPREHENSIVE PROTOCOL

1. INITIAL ASSESSMENT (First 10 minutes):
   - Blood pressure measurement (minimum 2 readings)
   - Patient history: duration, symptoms, previous treatment
   - Identify end-organ damage: cardiac, renal, neurological
   - Assess cardiovascular risk factors
   
2. CLASSIFICATION:
   - Normal: <120/<80 mmHg
   - Elevated: 120-129/<80 mmHg
   - Stage 1: 130-139/80-89 mmHg → Lifestyle modification 3-6 months
   - Stage 2: ≥140/≥90 mmHg → Consider pharmacotherapy
   - Hypertensive Crisis: >180/>120 mmHg → Immediate intervention
   
3. FIRST-LINE MEDICATIONS:
   - ACE Inhibitors: Lisinopril 10mg daily, Enalapril 10mg daily
   - ARBs: Losartan 50mg daily, Valsartan 80mg daily
   - Beta-blockers: Metoprolol 50mg daily, Atenolol 25mg daily
   - Calcium Channel Blockers: Amlodipine 5mg daily, Diltiazem 120mg daily
   - Thiazide Diuretics: Hydrochlorothiazide 12.5mg daily
   
4. DOSING & TITRATION:
   - Start low: 50% of maximum dose
   - Titrate every 2-4 weeks based on response
   - Target: <140/90 mmHg (or <130/80 in high-risk patients)
   - Maximum usually achieved in 2-3 months
   
5. MONITORING:
   - Home BP monitoring: daily for first month
   - Clinical visits: every 2 weeks initially, then monthly
   - ECG: baseline and if symptoms of LVH
   - Labs: electrolytes, creatinine, glucose at baseline and 4 weeks
   
6. COMPLICATIONS MANAGEMENT:
   - Hypertensive emergency: IV nitroprusside, nitroglycerin, labetalol
   - Hypertensive urgency: oral agent titration
   - Resistant hypertension: add third agent or refer
                """,
                "source": "WHO Guidelines 2023",
                "category": "Cardiovascular"
            },
            {
                "id": "chest_pain_001",
                "title": "Acute Coronary Syndrome Management",
                "content": """
ACUTE CORONARY SYNDROME (ACS) - EMERGENCY PROTOCOL

1. IMMEDIATE ACTIONS (0-10 minutes):
   ✓ Obtain 12-lead ECG within 10 minutes of presentation
   ✓ Establish IV access (18 gauge or larger)
   ✓ Apply continuous cardiac monitoring
   ✓ Administer oxygen if SpO2 <94%
   ✓ Give aspirin 325-500mg (chewed, NOT enteric-coated)
   ✓ Establish baseline labs: troponin, CBC, BMP, D-dimer
   
2. RISK STRATIFICATION (TIMI Score):
   Points for each: Age ≥65, ≥3 CAD risk factors, prior CAD, ST deviation, 
   elevated troponin, ≥2 anginal events in 24h
   - 0-1 points: Low risk
   - 2-4 points: Intermediate risk  
   - 5-7 points: High risk
   
3. PHARMACOTHERAPY:
   ANTIPLATELET:
   - Aspirin: 325mg immediately (if not contraindicated)
   - P2Y12 inhibitor: Clopidogrel 600mg, Prasugrel 60mg, Ticagrelor 180mg
   
   ANTICOAGULATION:
   - Unfractionated heparin: 60-70 U/kg IV bolus
   - Enoxaparin: 30mg IV + 1mg/kg SC q12h
   - Fondaparinux: 2.5mg IV daily
   
   BETA-BLOCKERS:
   - Metoprolol: 25-50mg q6-8h PO or 5mg q5min IV (max 15mg)
   - Atenolol: 25mg PO daily
   
   ACE-I/ARBs (if indicated):
   - Lisinopril: 5-10mg daily
   - Ramipril: 2.5-5mg daily
   
   STATINS:
   - High-intensity: Atorvastatin 80mg daily, Rosuvastatin 40mg daily
   
4. INVASIVE STRATEGY:
   - Primary PCI preferred if <12 hours from symptom onset
   - Time to balloon: <90 minutes
   - Fibrinolytic therapy if PCI not available within 120 minutes
   
5. MONITORING PARAMETERS:
   - Troponin: baseline, 3h, 6h (or high-sensitivity troponin at 0h, 1h, 3h)
   - ECG: Repeat at 5 minutes if no change
   - Vital signs: Continuous monitoring
   - Chest pain assessment: Every 15-30 minutes
                """,
                "source": "ACC/AHA Guidelines 2023",
                "category": "Cardiovascular"
            },
            {
                "id": "sepsis_001",
                "title": "Sepsis Management Bundle",
                "content": """
SEPSIS - RAPID RESPONSE PROTOCOL (First 3 Hours Critical)

1. IDENTIFICATION (0-30 minutes):
   Sepsis = infection + SIRS (2+ of):
   - Temperature >38°C or <36°C
   - Heart rate >90 bpm
   - Respiratory rate >20 breaths/min
   - WBC >12,000 or <4,000 or >10% immature bands
   
   Severe Sepsis = Sepsis + organ dysfunction
   Septic Shock = Severe Sepsis + persistent hypotension
   
2. IMMEDIATE INTERVENTIONS (0-1 hour):
   ✓ Blood cultures (before antibiotics!)
   ✓ Lactate measurement
   ✓ Full metabolic panel, CBC, coagulation studies
   ✓ Urinalysis and urine culture
   ✓ Imaging of suspected infection source
   ✓ IV access: 2 large bore lines
   ✓ Continuous monitoring: cardiac, BP, SpO2
   
3. FLUID RESUSCITATION (First 3 hours):
   - Crystalloid (normal saline or Lactated Ringer's): 30 mL/kg in first hour
   - Reassess after bolus: repeat if hypotensive or high lactate
   - Target CVP 8-12 mmHg
   - Target MAP ≥65 mmHg
   
4. BROAD-SPECTRUM ANTIBIOTICS (Within 1 hour):
   Community-acquired:
   - Ceftriaxone 2g Q12h + Azithromycin 500mg Q24h
   - OR Fluoroquinolone (Levofloxacin 750mg Q24h)
   
   Hospital-acquired:
   - Piperacillin-tazobactam 4.5g Q6h
   - OR Meropenem 1g Q8h
   
   If MRSA suspected: Add Vancomycin 15-20mg/kg Q8-12h
   If Candida suspected: Add Fluconazole 400-800mg Q24h
   
5. SOURCE CONTROL:
   - Drain accessible abscesses
   - Remove infected lines (central lines, foleys)
   - Surgical intervention if needed
   - Repeat imaging q24-48h to assess response
   
6. VASOPRESSOR SUPPORT (if MAP remains <65 after fluids):
   First line:
   - Norepinephrine: 0.04-0.4 mcg/kg/min IV infusion
   - Dopamine: 5-20 mcg/kg/min (if bradycardic)
   
   Second line (if first-line inadequate):
   - Epinephrine: 0.04-0.4 mcg/kg/min
   - Vasopressin: 0.04 units/min fixed
   
7. MONITORING & REASSESSMENT:
   - Lactate clearance: Check at 3 hours, target <10% reduction
   - Repeat lactate q2-4h until <2
   - Central venous oxygen saturation: Target >70%
   - Repeat assessments q4h minimum
                """,
                "source": "Surviving Sepsis Campaign 2023",
                "category": "Critical Care"
            },
            {
                "id": "stroke_001", 
                "title": "Acute Ischemic Stroke Protocol",
                "content": """
ACUTE ISCHEMIC STROKE - TIME-CRITICAL MANAGEMENT

GOLDEN WINDOW: First 4.5 hours for IV thrombolysis, 24h for thrombectomy

1. IMMEDIATE ASSESSMENT (0-10 minutes):
   ✓ Establish exact time of symptom onset (or last known well)
   ✓ NIH Stroke Scale assessment
   ✓ Fingerstick glucose (rule out hypoglycemia)
   ✓ Continuous cardiac/oxygen monitoring
   ✓ IV access x 2 large bore lines
   
2. STAT IMAGING:
   - Non-contrast head CT (rule out hemorrhage)
   - CT/MR angiography of head/neck (if thrombectomy considered)
   - CTA perfusion (if late presentation)
   
3. LABORATORY STUDIES:
   - CBC, CMP, coagulation panel, glucose
   - Troponin, D-dimer
   - Blood type and crossmatch
   
4. IV THROMBOLYSIS (if <4.5 hours from onset):
   Alteplase (rt-PA): 0.9 mg/kg (max 90mg)
   - 10% bolus over 1 minute
   - Remaining 90% over 60 minutes
   
   Inclusion criteria:
   - Ischemic stroke confirmed by imaging
   - Time from onset <4.5 hours
   - No major surgery in past 3 months
   - No current anticoagulation (with exceptions)
   
   Contraindications:
   - Hemorrhage on imaging
   - Severe hypertension (SBP >185 or DBP >110)
   - Platelet count <100,000
   - INR >1.7
   - Recent thromboembolic event
   
5. BLOOD PRESSURE MANAGEMENT:
   Before thrombolysis: Lower SBP to <185 if using thrombolytics
   - Nicardipine: 5-15mg/hr IV infusion
   - Labetalol: 10-20mg IV q10min (max 80mg)
   
   After thrombolysis: Target <180/105
   
6. MECHANICAL THROMBECTOMY:
   Indications: Large vessel occlusion, <24h from symptom
   Device: Stent retriever (Solitaire, Trevo)
   Goal: TIMI 2-3 reperfusion, mTICI ≥2b
   
7. POST-THROMBOLYSIS MONITORING:
   - Neuro checks q15min for 2 hours, then hourly for 24h
   - Watch for signs of hemorrhage: severe headache, weakness worsening
   - Hold antiplatelet/anticoagulation for 24h
   - Monitor glucose: <140 mg/dL
   
8. SECONDARY PREVENTION:
   - Aspirin: 325mg daily (start after 24h if IV tPA given)
   - Atorvastatin: 80mg daily
   - Clopidogrel: 600mg loading then 75mg daily (if aspirin contraindicated)
   - ACE-I: Lisinopril 10mg daily (if HTN)
   - Antidiabetic therapy optimization
                """,
                "source": "American Stroke Association 2023",
                "category": "Neurology"
            }
        ]
        
        documents = []
        for guideline in guidelines:
            doc = Document(
                page_content=guideline["content"],
                metadata={
                    "id": guideline["id"],
                    "title": guideline["title"],
                    "source": guideline["source"],
                    "category": guideline["category"],
                    "loaded_at": datetime.utcnow().isoformat()
                }
            )
            documents.append(doc)
        
        logger.info(f"Loaded {len(documents)} medical guidelines")
        return documents


class RAGPipeline:
    """Complete RAG pipeline: ingest, embed, store, retrieve"""
    
    def __init__(self, embeddings_model: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """Initialize RAG pipeline"""
        self.embeddings_model = embeddings_model
        self.embeddings = HuggingFaceEmbeddings(model_name=embeddings_model)
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            separators=["\n\n", "\n", ".", " ", ""]
        )
        self.vector_store = None
        self.documents = []
        self.chunks = []
        logger.info(f"RAG Pipeline initialized with model: {embeddings_model}")
    
    def ingest_documents(self, documents: List[Document]) -> int:
        """Ingest and chunk documents"""
        try:
            self.documents = documents
            
            for doc in documents:
                chunks = self.text_splitter.split_text(doc.page_content)
                for chunk in chunks:
                    self.chunks.append(Document(
                        page_content=chunk,
                        metadata=doc.metadata
                    ))
            
            logger.info(f"Ingested {len(documents)} documents into {len(self.chunks)} chunks")
            return len(self.chunks)
        except Exception as e:
            logger.error(f"Error ingesting documents: {e}")
            raise
    
    def embed_chunks(self) -> np.ndarray:
        """Generate embeddings for all chunks"""
        try:
            embeddings_list = []
            for chunk in self.chunks:
                embedding = self.embeddings.embed_query(chunk.page_content)
                embeddings_list.append(embedding)
            
            embeddings_array = np.array(embeddings_list).astype('float32')
            logger.info(f"Generated embeddings for {len(embeddings_list)} chunks")
            return embeddings_array
        except Exception as e:
            logger.error(f"Error embedding chunks: {e}")
            raise
    
    def create_faiss_index(self, embeddings: np.ndarray) -> faiss.IndexFlatL2:
        """Create FAISS index from embeddings"""
        try:
            dimension = embeddings.shape[1]
            index = faiss.IndexFlatL2(dimension)
            index.add(embeddings)
            logger.info(f"Created FAISS index with {index.ntotal} vectors")
            return index
        except Exception as e:
            logger.error(f"Error creating FAISS index: {e}")
            raise
    
    def retrieve(self, query: str, top_k: int = 5) -> List[Tuple[Document, float]]:
        """Retrieve relevant documents for query"""
        try:
            if not self.chunks or self.vector_store is None:
                logger.warning("Vector store not initialized")
                return []
            
            query_embedding = self.embeddings.embed_query(query)
            query_embedding = np.array([query_embedding]).astype('float32')
            
            distances, indices = self.vector_store.search(query_embedding, top_k)
            
            results = []
            for idx, distance in zip(indices[0], distances[0]):
                if idx < len(self.chunks):
                    score = 1 / (1 + distance)  # Convert distance to similarity score
                    results.append((self.chunks[idx], score))
            
            logger.info(f"Retrieved {len(results)} documents for query: {query[:50]}...")
            return results
        except Exception as e:
            logger.error(f"Error retrieving documents: {e}")
            return []
    
    def setup_pipeline(self) -> None:
        """Setup complete RAG pipeline"""
        try:
            # Load documents
            documents = MedicalDocumentLoader.load_medical_guidelines()
            
            # Ingest and chunk
            self.ingest_documents(documents)
            
            # Generate embeddings
            embeddings = self.embed_chunks()
            
            # Create FAISS index
            self.vector_store = self.create_faiss_index(embeddings)
            
            logger.info("✅ RAG Pipeline setup complete!")
        except Exception as e:
            logger.error(f"Error setting up RAG pipeline: {e}")
            raise


# Global pipeline instance
_rag_pipeline: Optional[RAGPipeline] = None


def get_rag_pipeline() -> RAGPipeline:
    """Get or create RAG pipeline singleton"""
    global _rag_pipeline
    if _rag_pipeline is None:
        _rag_pipeline = RAGPipeline()
        _rag_pipeline.setup_pipeline()
    return _rag_pipeline
