# React Web Dashboard (dashboard.jsx)
"""
React Dashboard Component - Smart Ambulance System
Features: Real-time vitals, AI pathways, ambulance tracking, bed availability
"""

import React, { useState, useEffect } from 'react';
import './dashboard.css';

const SmartAmbulanceDashboard = () => {
  const [vitals, setVitals] = useState({
    heart_rate: 72,
    blood_pressure_sys: 120,
    blood_pressure_dia: 80,
    oxygen_saturation: 98,
    respiratory_rate: 16,
    body_temperature: 37.0
  });

  const [pathway, setPathway] = useState(null);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [hospitals, setHospitals] = useState([]);
  const [activeTab, setActiveTab] = useState('vitals');
  const [mapCenter, setMapCenter] = useState({ lat: 28.6139, lng: 77.2090 });

  useEffect(() => {
    // Simulate real-time vitals update
    const interval = setInterval(() => {
      setVitals(prev => ({
        ...prev,
        heart_rate: prev.heart_rate + (Math.random() - 0.5) * 4,
        blood_pressure_sys: prev.blood_pressure_sys + (Math.random() - 0.5) * 2,
        oxygen_saturation: Math.max(95, Math.min(100, prev.oxygen_saturation + (Math.random() - 0.5)))
      }));
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);

  const generatePathway = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/pathways/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer token'
        },
        body: JSON.stringify({
          patient_id: 'PAT_001',
          vitals: {
            patient_id: 'PAT_001',
            ecg_reading: [0.5, 1.0, -1.5, 0.8],
            heart_rate: parseInt(vitals.heart_rate),
            oxygen_saturation: vitals.oxygen_saturation,
            blood_pressure_sys: parseInt(vitals.blood_pressure_sys),
            blood_pressure_dia: parseInt(vitals.blood_pressure_dia),
            respiratory_rate: vitals.respiratory_rate,
            body_temperature: vitals.body_temperature,
            gps_lat: 28.6139,
            gps_lon: 77.2090
          },
          symptoms: {
            patient_id: 'PAT_001',
            symptoms: ['Chest pain', 'Shortness of breath'],
            severity: 8,
            duration_minutes: 30,
            medical_history: ['Hypertension'],
            current_medications: ['Lisinopril'],
            allergies: ['Penicillin']
          }
        })
      });

      const data = await response.json();
      setPathway(data);
    } catch (error) {
      console.error('Error generating pathway:', error);
    }
  };

  const searchHospitals = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/hospitals/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer token'
        },
        body: JSON.stringify({
          latitude: 28.6139,
          longitude: 77.2090,
          radius_km: 10,
          bed_type: 'icu'
        })
      });

      const data = await response.json();
      setHospitals(data.hospitals);
    } catch (error) {
      console.error('Error searching hospitals:', error);
    }
  };

  const getVitalsStatus = () => {
    const hr = vitals.heart_rate;
    if (hr > 120 || hr < 50) return 'critical';
    if (hr > 100 || hr < 60) return 'warning';
    return 'normal';
  };

  const getConfidenceColor = (confidence) => {
    if (confidence > 0.8) return '#4CAF50';
    if (confidence > 0.6) return '#FF9800';
    return '#F44336';
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Smart Ambulance & Healthcare System</h1>
        <div className="user-info">
          <span>Dr. Sharma</span>
          <span>|</span>
          <span>Delhi Medical Center</span>
        </div>
      </header>

      <nav className="dashboard-nav">
        <button className={activeTab === 'vitals' ? 'active' : ''} onClick={() => setActiveTab('vitals')}>
          📊 Vitals
        </button>
        <button className={activeTab === 'pathway' ? 'active' : ''} onClick={() => setActiveTab('pathway')}>
          🔬 Care Pathway
        </button>
        <button className={activeTab === 'hospitals' ? 'active' : ''} onClick={() => setActiveTab('hospitals')}>
          🏥 Hospitals
        </button>
        <button className={activeTab === 'tracking' ? 'active' : ''} onClick={() => setActiveTab('tracking')}>
          🗺️ Tracking
        </button>
      </nav>

      <main className="dashboard-main">
        {/* VITALS TAB */}
        {activeTab === 'vitals' && (
          <section className="vitals-section">
            <h2>Real-Time Patient Vitals</h2>
            <div className="vitals-grid">
              <div className={`vital-card ${getVitalsStatus()}`}>
                <h3>❤️ Heart Rate</h3>
                <div className="vital-value">{vitals.heart_rate.toFixed(0)}</div>
                <div className="vital-unit">bpm</div>
                <div className="vital-range">Normal: 60-100</div>
              </div>

              <div className="vital-card normal">
                <h3>🫁 Oxygen Saturation</h3>
                <div className="vital-value">{vitals.oxygen_saturation.toFixed(1)}</div>
                <div className="vital-unit">%</div>
                <div className="vital-range">Normal: >95%</div>
              </div>

              <div className="vital-card normal">
                <h3>🩸 Blood Pressure</h3>
                <div className="vital-value">{vitals.blood_pressure_sys.toFixed(0)}/{vitals.blood_pressure_dia.toFixed(0)}</div>
                <div className="vital-unit">mmHg</div>
                <div className="vital-range">Normal: <120/80</div>
              </div>

              <div className="vital-card normal">
                <h3>🌡️ Temperature</h3>
                <div className="vital-value">{vitals.body_temperature.toFixed(1)}</div>
                <div className="vital-unit">°C</div>
                <div className="vital-range">Normal: 36.5-37.5</div>
              </div>

              <div className="vital-card normal">
                <h3>💨 Respiratory Rate</h3>
                <div className="vital-value">{vitals.respiratory_rate.toFixed(0)}</div>
                <div className="vital-unit">breaths/min</div>
                <div className="vital-range">Normal: 12-20</div>
              </div>

              <div className="vital-card normal">
                <h3>📈 ECG Status</h3>
                <div className="vital-value">Normal</div>
                <div className="vital-unit">Sinus Rhythm</div>
                <div className="vital-range">Regular</div>
              </div>
            </div>

            <button className="btn btn-primary" onClick={generatePathway}>
              Generate AI Pathway
            </button>
          </section>
        )}

        {/* PATHWAY TAB */}
        {activeTab === 'pathway' && (
          <section className="pathway-section">
            <h2>AI-Generated Care Pathway</h2>
            {pathway ? (
              <div className="pathway-container">
                <div className="pathway-header">
                  <div className="severity">
                    Severity: <strong>{pathway.severity_assessment}</strong>
                  </div>
                  <div className="confidence">
                    <div className="confidence-label">Confidence</div>
                    <div className="confidence-bar">
                      <div 
                        className="confidence-fill" 
                        style={{
                          width: `${pathway.overall_confidence * 100}%`,
                          backgroundColor: getConfidenceColor(pathway.overall_confidence)
                        }}
                      ></div>
                    </div>
                    <div>{(pathway.overall_confidence * 100).toFixed(1)}%</div>
                  </div>
                </div>

                <div className="clinical-summary">
                  <h3>Clinical Summary</h3>
                  <p>{pathway.clinical_summary}</p>
                </div>

                <div className="pathway-actions">
                  <h3>Clinical Actions</h3>
                  {pathway.actions.map((action, idx) => (
                    <div key={idx} className={`action-step urgency-${action.urgency}`}>
                      <div className="step-number">{action.step_number}</div>
                      <div className="step-content">
                        <div className="action-title">{action.action}</div>
                        <div className="action-details">
                          <span className="urgency">Urgency: {action.urgency.toUpperCase()}</span>
                          <span className="timeframe">⏱️ {action.time_frame_minutes} min</span>
                          <span className="responsible">👤 {action.responsible_party}</span>
                        </div>
                        {action.monitoring_parameters && (
                          <div className="monitoring">
                            Monitor: {action.monitoring_parameters.join(', ')}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pathway-review">
                  Next review in: {pathway.next_review_minutes} minutes
                </div>
              </div>
            ) : (
              <div className="empty-state">
                <p>No pathway generated yet. Generate one from the Vitals tab.</p>
              </div>
            )}
          </section>
        )}

        {/* HOSPITALS TAB */}
        {activeTab === 'hospitals' && (
          <section className="hospitals-section">
            <h2>Nearby Hospitals & Bed Availability</h2>
            <button className="btn btn-primary" onClick={searchHospitals}>
              Search Hospitals
            </button>

            <div className="hospitals-list">
              {hospitals.length > 0 ? (
                hospitals.map((hospital, idx) => (
                  <div key={idx} className="hospital-card">
                    <div className="hospital-header">
                      <h3>{hospital.name}</h3>
                      <div className="distance">📍 {hospital.distance_km.toFixed(1)} km</div>
                    </div>
                    <div className="hospital-details">
                      <div className="beds">
                        <div className="bed-type">
                          <span className="bed-label">🛏️ ICU Beds:</span>
                          <span className="bed-count">{hospital.icu_beds_available}</span>
                        </div>
                        <div className="bed-type">
                          <span className="bed-label">🛏️ General:</span>
                          <span className="bed-count">{hospital.general_beds_available}</span>
                        </div>
                        <div className="bed-type">
                          <span className="bed-label">🚑 Emergency:</span>
                          <span className="bed-count">{hospital.emergency_beds_available}</span>
                        </div>
                      </div>
                      <div className="specializations">
                        {hospital.specializations.map((spec, i) => (
                          <span key={i} className="spec-tag">{spec}</span>
                        ))}
                      </div>
                      <button className="btn btn-secondary">Reserve Bed</button>
                    </div>
                  </div>
                ))
              ) : (
                <p>Click "Search Hospitals" to find nearby facilities.</p>
              )}
            </div>
          </section>
        )}

        {/* TRACKING TAB */}
        {activeTab === 'tracking' && (
          <section className="tracking-section">
            <h2>Ambulance Real-Time Tracking</h2>
            <div className="map-container">
              <div className="map-placeholder">
                📍 Live Map View (28.6139° N, 77.2090° E)
              </div>
            </div>

            <div className="fleet-stats">
              <div className="stat">
                <div className="stat-value">15</div>
                <div className="stat-label">Active Ambulances</div>
              </div>
              <div className="stat">
                <div className="stat-value">8</div>
                <div className="stat-label">Responding</div>
              </div>
              <div className="stat">
                <div className="stat-value">3</div>
                <div className="stat-label">At Hospital</div>
              </div>
              <div className="stat">
                <div className="stat-value">4</div>
                <div className="stat-label">Available</div>
              </div>
            </div>
          </section>
        )}
      </main>

      <footer className="dashboard-footer">
        <p>Smart Ambulance System v1.0 | Real-time Medical Decision Support</p>
      </footer>
    </div>
  );
};

export default SmartAmbulanceDashboard;
