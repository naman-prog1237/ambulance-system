# backend/llm_service.py
"""
LLM Service for generating patient care pathways
Integrates with OpenAI, Cohere, or HuggingFace
"""

import logging
import json
import re
from datetime import datetime
from typing import List, Dict, Optional, Any
from config import settings
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain_community.llms import Cohere
from langchain_community.llms.huggingface_hub import HuggingFaceHub
from langchain_community.chat_models import ChatOpenAI

logger = logging.getLogger(__name__)

class LLMService:
    """
    Language Model Service for generating clinical pathways
    """

    def __init__(self, rag_service=None):
        """
        Initialize LLM service

        Args:
            rag_service: RAG service instance for context
        """
        self.rag_service = rag_service
        self.llm = None
        self._initialize_llm()
        self._setup_prompt_templates()

    def _initialize_llm(self):
        """Initialize LLM based on configuration"""
        try:
            provider = (settings.LLM_PROVIDER or "").lower()
            if provider == "openai":
                # ChatOpenAI with explicit API key
                self.llm = ChatOpenAI(
                    model="gpt-4o-mini",
                    temperature=0.3,
                    max_tokens=2000,
                    api_key=settings.OPENAI_API_KEY,
                )

            elif provider == "cohere":
                self.llm = Cohere(
                    cohere_api_key=settings.COHERE_API_KEY,
                    model="command-light",
                    temperature=0.3,
                    max_tokens=2000,
                )

            elif provider == "huggingface":
                self.llm = HuggingFaceHub(
                    repo_id="mistralai/Mistral-7B-Instruct-v0.1",
                    huggingfacehub_api_token=settings.HUGGINGFACE_API_KEY,
                    model_kwargs={"temperature": 0.3, "max_new_tokens": 2000},
                )

            else:
                logger.warning(f"Unknown LLM provider: {settings.LLM_PROVIDER}")
                self.llm = None

            logger.info(f"LLM initialized: {settings.LLM_PROVIDER}")

        except Exception as e:
            logger.error(f"Failed to initialize LLM: {e}")
            self.llm = None

    def _setup_prompt_templates(self):
        """Setup prompt templates for pathway generation"""
        self.pathway_prompt = PromptTemplate(
            input_variables=[
                "patient_vitals",
                "symptoms",
                "medical_guidelines",
                "medical_history",
                "patient_age",
            ],
            template=(
                "You are an expert emergency medicine physician. "
                "Generate a comprehensive, step-by-step patient care pathway "
                "based on the following information.\n\n"
                "PATIENT INFORMATION:\n"
                "Age: {patient_age}\n"
                "Medical History: {medical_history}\n\n"
                "CURRENT VITALS:\n"
                "{patient_vitals}\n\n"
                "REPORTED SYMPTOMS:\n"
                "{symptoms}\n\n"
                "RELEVANT MEDICAL GUIDELINES:\n"
                "{medical_guidelines}\n\n"
                "Based on this information, generate a detailed clinical pathway "
                "with the following JSON structure:\n"
                "{\n"
                ' "severity": "stable/warning/critical",\n'
                ' "overall_confidence": 0.0-1.0,\n'
                ' "clinical_summary": "Brief summary of assessment",\n'
                ' "actions": [\n'
                "  {\n"
                '   "step_number": 1,\n'
                '   "action": "Specific action description",\n'
                '   "urgency": "low/medium/high/critical",\n'
                '   "time_frame_minutes": 5,\n'
                '   "responsible_party": "Paramedic/Doctor/Nurse",\n'
                '   "prerequisites": [],\n'
                '   "monitoring_parameters": ["parameter1", "parameter2"]\n'
                "  }\n"
                " ],\n"
                ' "rag_sources": ["guideline_id1", "guideline_id2"],\n'
                ' "next_review_minutes": 5,\n'
                ' "warnings": ["warning1", "warning2"],\n'
                ' "recommendations": ["recommendation1"]\n'
                "}\n\n"
                "Ensure:\n"
                "1. Actions are in priority order\n"
                "2. Time frames are realistic\n"
                "3. Each action has clear responsibility assignment\n"
                "4. Confidence scores reflect clinical certainty\n"
                "5. Monitoring parameters are specific and measurable\n"
                "6. Warnings highlight critical concerns\n\n"
                "Generate only valid JSON, no additional text.\n"
            ),
        )

        self.confidence_scoring_prompt = PromptTemplate(
            input_variables=["assessment", "supporting_evidence"],
            template=(
                "Given this clinical assessment and supporting evidence, "
                "provide a confidence score (0.0 to 1.0) for the diagnosis/pathway.\n\n"
                "ASSESSMENT:\n"
                "{assessment}\n\n"
                "SUPPORTING EVIDENCE:\n"
                "{supporting_evidence}\n\n"
                "Respond with ONLY a JSON object:\n"
                "{\n"
                ' "confidence_score": 0.0-1.0,\n'
                ' "reasoning": "Brief explanation",\n'
                ' "factors_supporting": ["factor1", "factor2"],\n'
                ' "factors_uncertain": ["factor1", "factor2"],\n'
                ' "additional_tests_recommended": ["test1", "test2"]\n'
                "}\n"
            ),
        )

    def generate_care_pathway(
        self,
        vitals: Dict[str, Any],
        symptoms: Dict[str, Any],
        medical_history: List[str],
        age: int,
        condition: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Generate patient care pathway using LLM

        Args:
            vitals: Patient vital signs
            symptoms: Patient symptoms
            medical_history: Patient medical history
            age: Patient age
            condition: Patient condition hint

        Returns:
            Generated care pathway
        """
        try:
            vitals_text = self._format_vitals(vitals)
            symptoms_text = self._format_symptoms(symptoms)
            history_text = ", ".join(medical_history) if medical_history else "No significant history"

            guideline_text = ""
            guideline_sources: List[str] = []

            if self.rag_service:
                search_query = f"{condition} {' '.join(symptoms.get('symptoms', []))}"
                guidelines = self.rag_service.retrieve_guidelines(
                    query=search_query,
                    condition=condition,
                    top_k=3,
                )

                guideline_text = self._format_guidelines(guidelines)
                guideline_sources = [
                    g["metadata"].get("guideline_id")
                    for g in guidelines
                    if g.get("metadata")
                ]

            if self.llm is None:
                return self._generate_fallback_pathway(vitals, symptoms, condition)

            pathway_input = {
                "patient_vitals": vitals_text,
                "symptoms": symptoms_text,
                "medical_guidelines": guideline_text or "General emergency medicine guidelines",
                "medical_history": history_text,
                "patient_age": age,
            }

            chain = LLMChain(llm=self.llm, prompt=self.pathway_prompt)
            response = chain.run(**pathway_input)

            pathway_data = self._parse_llm_response(response)

            pathway_data["generated_at"] = datetime.utcnow().isoformat()
            pathway_data["rag_sources"] = guideline_sources

            confidence = self._calculate_confidence(vitals, symptoms, guideline_sources)
            pathway_data["overall_confidence"] = confidence

            logger.info(f"Generated care pathway with confidence: {confidence:.2f}")

            return pathway_data

        except Exception as e:
            logger.error(f"Error generating care pathway: {e}")
            return self._generate_fallback_pathway(vitals, symptoms, condition)

    def _format_vitals(self, vitals: Dict[str, Any]) -> str:
        """Format vitals for LLM"""
        vital_strings = [
            f"Heart Rate: {vitals.get('heart_rate', 'N/A')} bpm",
            f"Blood Pressure: {vitals.get('blood_pressure_sys')}/{vitals.get('blood_pressure_dia')} mmHg",
            f"Oxygen Saturation: {vitals.get('oxygen_saturation', 'N/A')}%",
            f"Respiratory Rate: {vitals.get('respiratory_rate', 'N/A')} breaths/min",
            f"Temperature: {vitals.get('body_temperature', 'N/A')}°C",
            f"ECG Status: {'Abnormal' if vitals.get('ecg_reading') else 'Normal'}",
        ]
        return "\n".join(vital_strings)

    def _format_symptoms(self, symptoms: Dict[str, Any]) -> str:
        """Format symptoms for LLM"""
        symptom_list = ", ".join(symptoms.get("symptoms", []))
        severity = symptoms.get("severity", "Unknown")
        duration = symptoms.get("duration_minutes", 0)
        return f"Symptoms: {symptom_list}\nSeverity: {severity}/10\nDuration: {duration} minutes"

    def _format_guidelines(self, guidelines: List[Dict[str, Any]]) -> str:
        """Format guidelines for LLM"""
        if not guidelines:
            return ""

        formatted = []
        for i, guideline in enumerate(guidelines, 1):
            formatted.append(
                f"\n--- GUIDELINE {i} ---\n"
                f"Condition: {guideline['metadata'].get('condition', 'N/A')}\n"
                f"Source: {guideline['metadata'].get('source', 'N/A')}\n"
                f"Content: {guideline['content'][:500]}...\n"
            )

        return "\n".join(formatted)

    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM JSON response"""
        try:
            json_match = re.search(r"\{[\s\S]*\}", response)
            if json_match:
                json_str = json_match.group()
                return json.loads(json_str)
            logger.warning("No JSON found in LLM response")
            return self._generate_fallback_pathway({}, {}, None)
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM JSON response: {e}")
            return self._generate_fallback_pathway({}, {}, None)

    def _calculate_confidence(
        self,
        vitals: Dict[str, Any],
        symptoms: Dict[str, Any],
        guideline_sources: List[str],
    ) -> float:
        """Calculate pathway confidence"""
        confidence = 0.5
        confidence += min(0.2, len(guideline_sources) * 0.1)

        vital_clarity = (
            sum(
                1
                for key in ["heart_rate", "blood_pressure_sys", "oxygen_saturation"]
                if key in vitals and vitals[key] is not None
            )
            / 3.0
        )

        confidence += vital_clarity * 0.2

        if symptoms.get("symptoms"):
            confidence += 0.1

        return min(0.95, max(0.3, confidence))

    def _generate_fallback_pathway(
        self,
        vitals: Dict[str, Any],
        symptoms: Dict[str, Any],
        condition: Optional[str],
    ) -> Dict[str, Any]:
        """Generate fallback pathway when LLM unavailable"""
        severity = "stable"
        hr = vitals.get("heart_rate", 0)
        bp_sys = vitals.get("blood_pressure_sys", 0)
        o2 = vitals.get("oxygen_saturation", 95)

        if hr > 120 or hr < 50 or bp_sys > 180 or bp_sys < 90 or o2 < 90:
            severity = "critical"
        elif hr > 100 or bp_sys > 160 or o2 < 94:
            severity = "warning"

        return {
            "severity": severity,
            "overall_confidence": 0.6,
            "clinical_summary": (
                f"Patient presenting with {', '.join(symptoms.get('symptoms', ['unspecified symptoms']))}. "
                f"Current vital signs show {severity} status."
            ),
            "actions": [
                {
                    "step_number": 1,
                    "action": "Establish IV access and continuous monitoring",
                    "urgency": "high",
                    "time_frame_minutes": 5,
                    "responsible_party": "Paramedic",
                    "prerequisites": [],
                    "monitoring_parameters": [
                        "Heart Rate",
                        "Blood Pressure",
                        "Oxygen Saturation",
                    ],
                },
                {
                    "step_number": 2,
                    "action": "Obtain 12-lead ECG if cardiac pathology suspected",
                    "urgency": "high",
                    "time_frame_minutes": 10,
                    "responsible_party": "Paramedic",
                    "prerequisites": [1],
                    "monitoring_parameters": ["ECG rhythm", "ST segments"],
                },
                {
                    "step_number": 3,
                    "action": "Transport to nearest appropriate hospital",
                    "urgency": "high" if severity == "critical" else "medium",
                    "time_frame_minutes": 15,
                    "responsible_party": "Paramedic",
                    "prerequisites": [1],
                    "monitoring_parameters": ["All vitals", "Patient response"],
                },
            ],
            "rag_sources": [],
            "next_review_minutes": 5 if severity == "critical" else 10,
            "warnings": (
                [
                    "LLM service unavailable - using fallback pathway",
                    f"Severity assessment: {severity}",
                ]
                if severity != "stable"
                else []
            ),
            "recommendations": (
                [
                    "Early hospital notification recommended",
                    "Prepare for emergency procedures",
                ]
                if severity == "critical"
                else []
            ),
        }


# Singleton instance
_llm_service: Optional[LLMService] = None

def get_llm_service(rag_service=None) -> LLMService:
    """Get or create LLM service singleton"""
    global _llm_service
    if _llm_service is None:
        _llm_service = LLMService(rag_service)
    return _llm_service
